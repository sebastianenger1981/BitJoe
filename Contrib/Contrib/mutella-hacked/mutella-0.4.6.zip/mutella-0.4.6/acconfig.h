/* Debug flags */
#undef _DEBUG
#undef CHECK_RANGE

/* other config flags */
#undef __STL_SOLTHREADS
#undef __USE_MALLOC

/* Define if the C++ compiler supports BOOL */
#undef HAVE_BOOL

#undef VERSION

#undef PACKAGE

/* Define if you need the GNU extensions to compile */
#undef _GNU_SOURCE

/* Define to `int' if <sys/types.h> and <sys/socket.h> doesn't define. */
#undef socklen_t

#undef HAVE_TERMIOS_FUNCS

#undef VA_COPY

#undef INSTALL_PREFIX

#undef INSTALL_DATA_DIR

#undef HAVE_READLINE_42
