/****************************************************************************
** $Id: mthread_unix.cpp,v 1.13 2002/07/06 18:20:55 maksik Exp $
**
** MThread class for Unix
**
** Created : 931107
**
** Copyright (C) 1992-2000 Trolltech AS.  All rights reserved.
**
** This file is part of the kernel module of the Qt GUI Toolkit.
**
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** This file may be distributed and/or modified under the terms of the
** GNU General Public License version 2 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.
**
** Licensees holding valid Qt Enterprise Edition or Qt Professional Edition
** licenses for Unix/X11 or for Qt/Embedded may use this file in accordance
** with the Qt Commercial License Agreement provided with the Software.
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** See http://www.trolltech.com/pricing.html or email sales@trolltech.com for
**   information about Qt Commercial License Agreements.
** See http://www.trolltech.com/qpl/ for QPL licensing information.
** See http://www.trolltech.com/gpl/ for GPL licensing information.
**
** Contact info@trolltech.com if any conditions of this licensing are
** not clear to you.
**
**********************************************************************/
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

//
// The operating system, must be one of: (_OS_x_)
//
//   MAC	- Macintosh
//   MSDOS	- MS-DOS and Windows
//   OS2	- OS/2
//   OS2EMX	- XFree86 on OS/2 (not PM)
//   WIN32	- Win32 (Windows 95/98 and Windows NT)
//   CYGWIN - Cygnus unix simulator under win32
//   SUN	- SunOS
//   SOLARIS	- Sun Solaris
//   HPUX	- HP-UX
//   ULTRIX	- DEC Ultrix
//   LINUX	- Linux
//   FREEBSD	- FreeBSD
//   NETBSD	- NetBSD
//   OPENBSD    - OpenBSD
//   IRIX	- SGI Irix
//   OSF	- OSF Unix
//   BSDI	- BSDI Unix
//   SCO	- SCO of some sort
//   AIX	- AIX Unix
//   UNIXWARE	- SCO UnixWare
//   GNU	- GNU Hurd
//   DGUX	- DG Unix
//   DYNIX	- Dynix
//   UNIX	- Any UNIX bsd/sysv system
//

#if defined(macintosh)
#define _OS_MAC_
#elif defined(MSDOS) || defined(_MSDOS) || defined(__MSDOS__)
#define _OS_MSDOS_
#elif defined(OS2) || defined(_OS2) || defined(__OS2__)
#if defined(__EMX__)
#define _OS_OS2EMX_
#else
#define _OS_OS2_
#endif
#elif defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__)
#define _OS_WIN32_
#elif defined(__MWERKS__) && defined(__INTEL__)
#define _OS_WIN32_
// TODO: fix configure to enable -lthread ob Solaris
/*#elif defined(sun) || defined(__sun) || defined(__sun__)
#if defined(__SVR4)
#warning "#define _OS_SOLARIS_"
#define _OS_SOLARIS_
#else
#define _OS_SUN_
#endif*/
#elif defined(hpux) || defined(__hpux) || defined(__hpux__)
#define _OS_HPUX_
#elif defined(ultrix) || defined(__ultrix) || defined(__ultrix__)
#define _OS_ULTRIX_
#elif defined(reliantunix)
#define _OS_RELIANTUNIX_
#elif defined(__CYGWIN__)
#define _OS_CYGWIN_
#elif defined(linux) || defined(__linux) || defined(__linux__)
#define _OS_LINUX_
#elif defined(__FreeBSD__)
#define _OS_FREEBSD_
#elif defined(__NetBSD__)
#define _OS_NETBSD_
#elif defined(__OpenBSD__)
#define _OS_OPENBSD_
#elif defined(__APPLE__)
#define _OS_DARWIN_
#elif defined(sgi) || defined(__sgi)
#define _OS_IRIX_
#elif defined(__osf__)
#define _OS_OSF_
#elif defined(bsdi) || defined(__bsdi__)
#define _OS_BSDI_
#elif defined(_AIX)
#define _OS_AIX_
#elif defined(__Lynx__)
#define _OS_LYNXOS_
#elif defined(_UNIXWARE)
#define _OS_UNIXWARE_
#elif defined(__GNU__)
#define _OS_GNU_
#elif defined(DGUX)
#define _OS_DGUX_
#elif defined(__QNX__)
#define _OS_QNX_
#elif defined(_SCO_DS) || defined(M_UNIX) || defined(M_XENIX)
#define _OS_SCO_
#elif defined(sco) || defined(_UNIXWARE7)
#define _OS_UNIXWARE7_
#elif !defined(_SCO_DS) && defined(__USLC__) && defined(__SCO_VERSION__)
#define _OS_UNIXWARE7_
#elif defined(_SEQUENT_)
#define _OS_DYNIX_
#else
#warning "UNKNOWN SYSTEM TYPE -- threads might not work"
#endif

#if defined(_OS_MAC_) || defined(_OS_MSDOS_) || defined(_OS_OS2_) || defined(_OS_WIN32_)
#undef	_OS_UNIX_
#elif !defined(_OS_UNIX_)
#define _OS_UNIX_
#endif

#if defined(_OS_LINUX_)
# define _GNU_SOURCE
# define __USE_UNIX98
#endif

#ifdef _DEBUG
#include <assert.h>
#endif

#include "mthread.h"
#include "xsleep.h"

#include <stdio.h>
//#include <pthread.h>
//#include <stdio.h>
#include <sys/types.h>
//#include <sys/socket.h>
//#include <netinet/in.h>
//#include <arpa/inet.h>
//#include <netdb.h>
//#include <errno.h>

#include "defines.h"
#include "mthread_p.h"


/**************************************************************************
 ** MMutex
 *************************************************************************/

/*!
  \class MMutex qthread.h
  \brief The MMutex class provides access serialization between threads.

  \ingroup environment

  The purpose of a MMutex is to protect an object, data structure
  or section of code so that only one thread can access it at a time
  (In Java terms, this is similar to the synchronized keyword).
  For example, say there is a method which prints a message to the
  user on two lines:

  \code
  void someMethod()
  {
     qDebug("Hello");
     qDebug("World");
  }
  \endcode

  If this method is called simultaneously from two threads then
  the following sequence could result:

  \code
  Hello
  Hello
  World
  World
  \endcode

  If we add a mutex:

  \code
  MMutex mutex;

  void someMethod()
  {
     mutex.lock();
     qDebug("Hello");
     qDebug("World");
     mutex.unlock();
  }
  \endcode

  In Java terms this would be:

  \code
  void someMethod()
  {
     synchronized {
       qDebug("Hello");
       qDebug("World");
     }
  }
  \endcode

  Then only one thread can execute someMethod at a time and the order
  of messages is always correct. This is a trivial example, of course,
  but applies to any other case where things need to happen in a particular
  sequence.

*/


/*!
  Constructs a new mutex. The mutex is created in an unlocked state. A
  recursive mutex is created if \a recursive is TRUE; a normal mutex is
  created if \a recursive is FALSE (default argument). With a recursive
  mutex, a thread can lock the same mutex multiple times and it will
  not be unlocked until a corresponding number of unlock() calls have
  been made.
*/
MMutex::MMutex(bool recursive)
{
    if (recursive)
		d = new MRMutexPrivate();
    else
		d = new MMutexPrivate();
	ASSERT(d);
}


/*!
  Destroys the mutex.
*/
MMutex::~MMutex()
{
    delete d;
}


/*!
  Attempt to lock the mutex. If another thread has locked the mutex
  then this call will block until that thread has unlocked it.

  \sa unlock()
*/
void MMutex::lock()
{
    d->lock();
}


/*!
  Unlocks the mutex. Attempting to unlock a mutex in a different thread
  to the one that locked it results in an error.  Unlocking a mutex that
  is not locked results in undefined behaviour (varies between
  different Operating Systems' thread implementations).

  \sa lock()
*/
void MMutex::unlock()
{
    d->unlock();
}


/*!
  Returns TRUE if the mutex is locked by another thread and FALSE if not.

  \e NOTE: Due to differing implementations of recursive mutexes on various
  platforms, calling this function from the same thread that previous locked
  the mutex will return undefined results.
*/
bool MMutex::locked()
{
    return d->locked();
}


/**************************************************************************
 ** MThreadQtEvent
 *************************************************************************/

// this is for the magic MThread::postEvent()
/*class MThreadQtEvent
{
public:
    MThreadQtEvent(QObject *r, QEvent *e)
	: receiver(r), event(e)
    { ; }

    QObject *receiver;
    QEvent *event;
};


class MThreadPostEventPrivate : public QObject
{
    Q_OBJECT
public:
    MThreadPostEventPrivate();

    QList<MThreadQtEvent> events;
    MMutex eventmutex;

public slots:
    void sendEvents();
};


MThreadPostEventPrivate::MThreadPostEventPrivate()
{
    events.setAutoDelete( TRUE );
    // TODO: something reasonable
    assert(0);
    //connect( qApp, SIGNAL( guiThreadAwake() ), this, SLOT( sendEvents() ) );
}


// this is called from the QApplication::guiThreadAwake signal, and the
// application mutex is already locked
void MThreadPostEventPrivate::sendEvents()
{
    eventmutex.lock();

    MThreadQtEvent *qte;
    for( qte = events.first(); qte != 0; qte = events.next() ) {
	qApp->postEvent( qte->receiver, qte->event );
    }

    events.clear();

    // ## let event compression take full effect
    // qApp->sendPostedEvents();

    eventmutex.unlock();
}


static MThreadPostEventPrivate * qthreadposteventprivate = 0;
*/

/**************************************************************************
 ** MThread
 *************************************************************************/

/*!
  \class MThread qthread.h
  \brief The MThread class provides platform-independent threads

  \ingroup environment

  A MThread represents a separate thread of control within the program;
  it shares all data with other threads within the process but
  executes independently in the way that a separate program does on
  a multitasking operating system. Instead of starting in main(),
  however, MThreads begin executing in run(), which you inherit
  to provide your code. For instance:

  \code
  class MyThread : public MThread {

  public:

    virtual void run();

  };

  void MyThread::run()
  {
    for(int count=0;count<20;count++) {
      sleep(1);
      qDebug("Ping!");
    }
  }

  int main()
  {
      MyThread a;
      MyThread b;
      a.start();
      b.start();
      a.wait();
      b.wait();
  }
  \endcode

  This will start two threads, each of which writes Ping! 20 times
  to the screen and exits. The wait() calls at the end of main() are
  necessary because exiting main() ends the program, unceremoniously
  killing all other threads. Each MyThread stops executing when it
  reaches the end of MyThread::run(), just as an application does when
  it leaves main().

  See also the paragraph on <a href="threads.html">Thread Support in Qt</a>.
*/


/*!
  This returns the thread handle of the currently executing thread.  The
  handle returned by this function is used for internal reasons and
  should not be used in any application code.
  On Windows, the returned value is a pseudo handle for the current thread,
  and it can not be used for numerical comparison.
*/
HANDLE MThread::currentThread()
{
#if defined(_OS_SOLARIS_)
    return (HANDLE) thr_self();
#else
    return (HANDLE) pthread_self();
#endif
}

HANDLE MThread::getHandle()
{
	return (HANDLE) d->thread_id;
}

bool MThread::isCurrent()
{
#if defined(_OS_SOLARIS_)
	return d->thread_id == thr_self();
#else
	return pthread_equal(d->thread_id, pthread_self());
#endif
}

/*!
  Provides a way of posting an event from a thread which is not the
  event thread to an object. The event is put into a queue, then the
  event thread is woken which then sends the event to the object.
  It is important to note that the event handler for the event, when called,
  will be called from the event thread and not from the thread calling
  MThread::postEvent().

  Same as with \l QApplication::postEvent(), \a event must be allocated on the
  heap, as it is deleted when the event has been posted.
*/
/*void MThread::postEvent( QObject * receiver, QEvent * event )
{
    if( !qthreadposteventprivate )
	qthreadposteventprivate = new MThreadPostEventPrivate();

    qthreadposteventprivate->eventmutex.lock();
    qthreadposteventprivate->events.append( new MThreadQtEvent(receiver, event) );
    qApp->wakeUpGuiThread();
    qthreadposteventprivate->eventmutex.unlock();
}*/


/*!
  System independent sleep.  This causes the current thread to sleep for
  \a secs seconds.
*/
void MThread::sleep( unsigned long secs )
{
    // Chain 'em.  We just don't care.
    msleep(secs*1000L);
}


/*!
  System independent sleep.  This causes the current thread to sleep for
  \a msecs milliseconds
*/
void MThread::msleep( unsigned long msecs )
{
    // Chain 'em.  We just don't care.
    usleep(msecs*1000L);
}


/*!
  System independent sleep.  This causes the current thread to sleep for
  \a usecs microseconds
*/
void MThread::usleep( unsigned long usecs )
{
    // Void functions will *not* tell you if they actually slept that long.
    // Bad show, qT team.
    struct timespec rqtp, rmtp;
    rqtp.tv_nsec = usecs * 1000L;
    rqtp.tv_sec = rmtp.tv_sec = rmtp.tv_nsec = 0;

    safe_nanosleep(&rqtp, &rmtp);
}

/*!
  Constructs a new thread. The thread does not actually begin executing
  until start() is called.
*/
MThread::MThread(bool bAutoDelete /*=false*/)
{
    d = new MThreadPrivate;
    ASSERT(d);
    d->autodelete = bAutoDelete;
}


/*!
  MThread destructor. Note that deleting a MThread object will not stop
  the execution of the thread it represents.
*/
MThread::~MThread()
{
    delete d;
}


/*!
  Ends execution of the calling thread and wakes up any threads waiting
  for its termination.
*/
void MThread::exit()
{
	// we have to stop the thread object first
#if defined(_OS_SOLARIS_)
	thr_exit(0);
#else
	pthread_exit(0);
#endif
	//
	dictMutex->lock();
	MapHndlTrd::iterator it = thrDict->find(MThread::currentThread());
	if ( it != thrDict->end() ) {
		MThread *there = (*it).second;
		ASSERT(there);
		there->d->running = FALSE;
		there->d->finished = TRUE;
		MWaitCondition* pWait = there->d->thread_done;
		there->d->thread_done = NULL;
		
		if (there->d->autodelete)
		{
			thrDict->erase(it);
			dictMutex->unlock();
			// delete the object
			delete there;
			pWait->wakeAll();
			delete pWait;
			return;
		}
		pWait->wakeAll();
		delete pWait; // this will destroy object while other threads can still be around "wait"
	}
	dictMutex->unlock();
}

/*!
  This allows similar functionality to POSIX pthread_join.  A thread
  calling this will block until one of 2 conditions is met:
  <ul>
  <li> The thread associated with this MThread object has finished
       execution (i.e. when it returns from run() ).  This
       function will return TRUE if the thread has finished.
       It also returns TRUE if the thread has not been started yet.
  <li> \a time milliseconds has elapsed.  If \a time is ULONG_MAX (default
       argument), then the wait will never timeout (the thread must
       return from run() ).  This function will return FALSE
       if the wait timed out.
  </ul>
*/
bool MThread::wait(unsigned long time)
{
	MLock lock(*dictMutex);
	if (d->finished || ! d->running || !d->thread_done)
		return TRUE;
	return d->thread_wait(dictMutex, time);
}

bool MThread::wait( MMutex* mutex, unsigned long time /*=ULONG_MAX*/ )
{
	MLock lock(*dictMutex);
	if (d->finished || ! d->running || !d->thread_done)
		return TRUE;
	if (mutex)
		mutex->unlock();
	bool bRes = d->thread_wait(dictMutex, time);
	if (mutex)
		mutex->lock();
	return bRes;
}

/*!
  This begins actual execution of the thread by calling run(),
  which should be reimplemented in a MThread subclass to contain your code.
  If you try to start a thread that is already running, this call will
  wait until the thread has finished, and then restart the thread.
*/
void MThread::start()
{
    if (d->running) {
#ifdef CHECK_RANGE
	fprintf(stderr,"MThread::start: thread already running");
#endif

	wait();
    }

    //cout << "S" << flush;

    d->init(this);
}

/*!
  Sets AutoDelete flag which allows automatic memory clean-up upon the completion
  of the thread.
*/
void MThread::setAutoDelete()
{
	d->autodelete = true;
}

/*!
  Returns TRUE is the thread is finished.
*/
bool MThread::finished() const
{
    return d->finished;
}


/*!
  Returns TRUE if the thread is running.
*/
bool MThread::running() const
{
    return d->running;
}


/*! \fn void MThread::run()

  This method is pure virtual, and it must be implemented in derived classes
  in order to do useful work. Returning from this method will end execution
  of the thread.
*/


/**************************************************************************
 ** QWaitCondition
 *************************************************************************/

/*!
  \class QWaitCondition qthread.h
  \brief The QWaitCondition class allows waiting/waking for conditions
	 between threads

  \ingroup environment

  QWaitConditions allow a thread to tell other threads that some sort of
  condition has been met; one or many threads can block waiting for a
  QWaitCondition to set a condition with wakeOne() or wakeAll.  Use
  wakeOne() to wake one randomly-selected event or wakeAll() to wake them
  all. For example, say we have three tasks that should be performed every
  time the user presses a key; each task could be split into a thread, each
  of which would have a run() body like so:

  \code
  QWaitCondition key_pressed;

  while(1) {
     key_pressed.wait();    // This is a QWaitCondition global variable
     // Key was pressed, do something interesting
     do_something();
  }
  \endcode

  A fourth thread would read key presses and wake the other three threads
  up every time it receives one, like so:

  \code
  QWaitCondition key_pressed;

  while(1) {
     getchar();
     // Causes any thread in key_pressed.wait() to return from
     // that method and continue processing
     key_pressed.wakeAll();
  }
  \endcode

  Note that the order the three threads are woken up in is undefined,
  and that if some or all of the threads are still in do_something()
  when the key is pressed, they won't be woken up (since they're not
  waiting on the condition variable) and so the task will not be performed
  for that key press.  This can be avoided by, for example, doing something
  like this:

  \code
  MMutex mymutex;
  QWaitCondition key_pressed;
  int mycount=0;

  // Worker thread code
  while(1) {
     key_pressed.wait();    // This is a QWaitCondition global variable
     mymutex.lock();
     mycount++;
     mymutex.unlock();
     do_something();
     mymutex.lock();
     mycount--;
     mymutex.unlock();
  }

  // Key reading thread code
  while(1) {
     getchar();
     mymutex.lock();
     // Sleep until there are no busy worker threads
     while(count>0) {
       mymutex.unlock();
       sleep(1);
       mymutex.lock();
     }
     mymutex.unlock();
     key_pressed.wakeAll();
  }
  \endcode

  The mutexes are necessary because the results if two threads
  attempt to change the value of the same variable simultaneously
  are unpredictable.

*/


/*!
  Constructs a new event signalling object.
*/
MWaitCondition::MWaitCondition()
{
    d = new MWaitConditionPrivate;
    ASSERT(d);
}


/*!
  Deletes the event signalling object.
*/
MWaitCondition::~MWaitCondition()
{
	// MZ: added reference counting for wait()
    d->release();
}


/*!
  Wait on the thread event object. The thread calling this will block
  until one of 2 conditions is met:
  <ul>
  <li> Another thread signals it using wakeOne() or wakeAll(). This
       function will return TRUE in this case.
  <li> \a time milliseconds has elapsed.  If \a time is ULONG_MAX (default
       argument), then the wait will never timeout (the event must
       signalled).  This function will return FALSE if the
       wait timed out.
  </ul>

  \sa wakeOne(), wakeAll()
*/
bool MWaitCondition::wait(unsigned long time)
{
    return d->wait(time);
}


/*!
  Release the locked \a mutex and wait on the thread event object. The
  \a mutex must be initially locked by the calling thread.  If \a mutex
  is not in a locked state, this function returns immediately.  The
  \a mutex will be unlocked, and the thread calling will block until
  one of 2 conditions is met:
  <ul>
  <li> Another thread signals it using wakeOne() or wakeAll(). This
       function will return TRUE in this case.
  <li> \a time milliseconds has elapsed.  If \a time is ULONG_MAX (default
       argument), then the wait will never timeout (the event must
       signalled).  This function will return FALSE if the
       wait timed out.
  </ul>

  The mutex will be returned to the same locked state.  This function is
  provided to allow the atomic transition from the locked state to the
  wait state.

  \sa wakeOne(), wakeAll()
*/
bool MWaitCondition::wait(MMutex *mutex, unsigned long time)
{
    return d->wait(mutex, time);
}


/*!
  This wakes one thread waiting on the MWaitCondition.  The thread that
  woken up depends on the operating system's scheduling policies, and
  cannot be controlled or predicted.

  \sa wakeAll()
*/
void MWaitCondition::wakeOne()
{
    d->wakeOne();
}


/*!
  This wakes all threads waiting on the MWaitCondition.  The order in
  which the threads are woken up depends on the operating system's
  scheduling policies, and cannot be controlled or predicted.

  \sa wakeOne()
*/
void MWaitCondition::wakeAll()
{
    d->wakeAll();
}


/**************************************************************************
 ** MSemaphore
 *************************************************************************/
/*!
  \class MSemaphore qthread.h
  \brief The MSemaphore class provides a robust integer semaphore.

  \ingroup environment

  MSemaphore can be used to serialize thread execution, similar to a
  MMutex.  A semaphore differs from a mutex, in that a semaphore can be
  accessed by more than one thread at a time.

  An example would be an application that stores data in a large tree
  structure.  The application creates 10 threads (commonly called a
  thread pool) to do searches on the tree.  When the application searches
  the tree for some piece of data, it uses one thread per base node to
  do the searching.  A semaphore could be used to make sure that 2 threads
  don't try to search the same branch of the tree.

  A real world example of a semaphore would be dining at a restuarant.
  A semaphore initialized to have a maximum count equal to the number
  of chairs in the restuarant.  As people arrive, they want a seat.  As
  seats are filled, the semaphore is accessed, once per person.  As people
  leave, the access is released, allowing more people to enter. If a
  party of 10 people want to be seated, but there are only 9 seats, those
  10 people will wait, but a party of 4 people would be seated (taking
  the available seats to 5, making the party of 10 people wait longer).
*/


class MSemaphorePrivate {
public:
    MSemaphorePrivate(int);
    ~MSemaphorePrivate();

    MMutex mutex;
    MWaitCondition cond;

    int value, max;
};


MSemaphorePrivate::MSemaphorePrivate(int m)
    : mutex(), value(0), max(m)
{
}


MSemaphorePrivate::~MSemaphorePrivate()
{
}


/*!
  Creates a new semaphore.  The semaphore can be concurrently accessed at
  most \a maxcount times.
*/
MSemaphore::MSemaphore(int maxcount)
{
    d = new MSemaphorePrivate(maxcount);
    ASSERT(d);
}


/*!
  Destroys the semaphore.
*/
MSemaphore::~MSemaphore()
{
    delete d;
}


/*!
  Postfix ++ operator.

  Try to get access to the semaphore.  If \l available() is >= \l total(),
  this call will block until it can get access.
*/
int MSemaphore::operator++(int)
{
    int ret;

    d->mutex.lock();

    while (d->value >= d->max)
	d->cond.wait(&(d->mutex));

    ++(d->value);
    if (d->value > d->max) d->value = d->max;
    ret = d->value;

    d->mutex.unlock();

    return ret;
}


/*!
  Postfix -- operator.

  Release access of the semaphore.  This wakes all threads waiting for
  access to the semaphore.
 */
int MSemaphore::operator--(int)
{
    int ret;

    d->mutex.lock();

    --(d->value);
    if (d->value < 0) d->value = 0;
    ret = d->value;

    d->cond.wakeAll();
    d->mutex.unlock();

    return ret;
}


/*!
  Try to get access to the semaphore.  If \l available() is >= \l total(),
  the calling thread blocks until it can get access.   The calling will
  only get access from the semaphore if it can get all \a n accesses
  at once.
*/
int MSemaphore::operator+=(int n)
{
    int ret;

    d->mutex.lock();

    while (d->value + n > d->max)
	d->cond.wait(&(d->mutex));

    d->value += n;

#ifdef CHECK_RANGE
    if (d->value > d->max) {
	fprintf(stderr,"MSemaphore::operator+=: attempt to allocate more resources than available");
	d->value = d->max;
    }
#endif

    ret = d->value;

    d->mutex.unlock();

    return ret;
}


/*!
  Release \a n accesses to the semaphore.
 */
int MSemaphore::operator-=(int n)
{
    int ret;

    d->mutex.lock();

    d->value -= n;

#ifdef CHECK_RANGE
    if (d->value < 0) {
	fprintf(stderr,"MSemaphore::operator-=: attempt to deallocate more resources than taken");
	d->value = 0;
    }
#endif

    ret = d->value;

    d->cond.wakeOne();
    d->mutex.unlock();

    return ret;
}


/*!
  This function returns the number of accesses currently available to
  the semaphore.
 */
int MSemaphore::available() const {
    int ret;

	d->mutex.lock();
    ret = d->max - d->value;
    d->mutex.unlock();

    return ret;
}


/*!
  This function returns the total number of accesses to the semaphore.
 */
int MSemaphore::total() const {
    int ret;

    d->mutex.lock();
    ret = d->max;
    d->mutex.unlock();

    return ret;
}


//#include "qthread_unix.moc"

//#endif

