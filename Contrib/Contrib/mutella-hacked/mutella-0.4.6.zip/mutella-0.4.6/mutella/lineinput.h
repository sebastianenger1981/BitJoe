/***************************************************************************
 Mutella - A commandline/HTTP client for the Gnutella filesharing network.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 lineinput.h  -  Input line and command completion capabilities for term UI
 
    begin                : Sat Jan 26 2002
    copyright            : (C) 2002 by Max Zaitsev
    email                : maksik@gmx.co.uk
 ***************************************************************************/

#ifndef LINEINPUT_H
#define LINEINPUT_H

class MLineInput {
public: 
	MLineInput();
	virtual ~MLineInput();
	//
	bool Init(FILE* fpInput, FILE* fpOutput);
	void Close();
	//
	CString InputLine(LPCSTR szPrompt);
	//
	virtual bool CompleteWord(const CString& part, list<CString>& listCompletions);
protected:
	//
	CString m_sLast;
	void* m_pPrivate;
};

#endif

