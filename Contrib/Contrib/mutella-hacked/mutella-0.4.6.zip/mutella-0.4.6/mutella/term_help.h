/***************************************************************************
 Mutella - A commandline/HTTP client for the Gnutella filesharing network.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 term.h  -  Helper and wrapper functions for terminal activities.

    begin                : Thu Nov 1 2001
    copyright            : (C) 2001 by Max Zaitsev
    email                : maksik@gmx.co.uk
 ***************************************************************************/
 
#ifndef __TERM_HELP_H_INCLUDED__
#define __TERM_HELP_H_INCLUDED__

#ifdef __cplusplus
extern "C" {
#endif

char read_key(int wait /*time to wait in seconds. wait<0 means infinity */); /*returns '\0' if time expires*/
int  wait_key(int wait /*time to wait in seconds. wait<0 means infinity */); /*returns 0 if time expires*/
void guess_term_size(int* Cols, int* Lines);

#ifdef __cplusplus
};
#endif

#endif /*__TERM_HELP_H_INCLUDED__*/

