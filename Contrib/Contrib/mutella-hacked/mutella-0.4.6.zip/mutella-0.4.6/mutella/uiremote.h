/***************************************************************************
 Mutella - A commandline/HTTP client for the Gnutella filesharing network.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 uiremote.h  -  User interface code for the HTTP UI.

    begin                : Thu Jan 31 2002
    copyright            : (C) 2002 by Max Zaitsev
    email                : maksik@gmx.co.uk
 ***************************************************************************/

#ifndef UIREMOTE_H
#define UIREMOTE_H

class MUIRemotePriv;

class MUIRemote : public MUI  {
public: 
	MUIRemote();
	virtual ~MUIRemote();
	
	virtual bool Attach(MController* pC);
	virtual bool Init();
	virtual void Detach();
	virtual void Do();
	virtual void Stop();
	virtual MMutex* GetMutex(){return &m_mutex;}
	// something very special
	virtual bool OnHttpRequest(const IP& ipRemoteHost, LPCSTR szPath, LPCSTR szHandshake, const char* pBuffRest, int nFD);
protected:
	MMutex m_mutex;
	MUIRemotePriv* m_pPriv;
};

#endif

