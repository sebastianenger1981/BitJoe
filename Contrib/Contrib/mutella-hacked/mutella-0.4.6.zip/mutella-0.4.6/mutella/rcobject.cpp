/***************************************************************************
 Mutella - A commandline/HTTP client for the Gnutella filesharing network.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 rcobject.cpp  -  A reference counting object class, including smartpointer.

    begin                : Sun Jan 6 2002
    copyright            : (C) 2002 by 
    email                : 
 ***************************************************************************/
 
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "mutella.h"
#include "rcobject.h"

MRCObject::MRCObject() : m_nRefs(1){
}

MRCObject::MRCObject(bool bRecursive) : m_nRefs(1), m_mutex(bRecursive) {
}
MRCObject::~MRCObject(){
}

