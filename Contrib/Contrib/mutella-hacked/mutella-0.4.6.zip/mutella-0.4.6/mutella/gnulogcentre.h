/***************************************************************************
                          gnulogcentre.h  -  description
                             -------------------
    begin                : Tue Oct 8 2002
    copyright            : (C) 2002 by Max Zaitsev
    email                : maksik@gmx.co.uk
 ***************************************************************************/

#ifndef GNULOGCENTRE_H
#define GNULOGCENTRE_H

class MEventQueueLog;
class MEvent;
class MController;

class MGnuLogCentre : public MThread  {
public: 
	MGnuLogCentre(MController* pController);
	~MGnuLogCentre();

	virtual void run();
protected:
	void logEvent(MEvent* pEvent, const CString& sFile, int nMaxTime, int nTrimTime);
	//
	MEventQueueLog* m_pEventQueue;
	MController* m_pController;
};

#endif
