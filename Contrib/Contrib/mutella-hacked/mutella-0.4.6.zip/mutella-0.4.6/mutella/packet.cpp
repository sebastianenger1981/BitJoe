/***************************************************************************
 Mutella - A commandline/HTTP client for the Gnutella filesharing network.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 packet.cpp  -  Node and packet definitions for gnutella protocol.
 
 the original version of this file was taken from Gnucleus (http://gnucleus.sourceforge.net)

    begin                : Tue May 29 2001
    copyright            : (C) 2001 by
    email                : maksik@gmx.co.uk
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "mutella.h"
#include "basicstruct.h"
#include "packet.h"


/*WORD  flipW(WORD in)
{
	BYTE *out = (BYTE *) &in;

	BYTE temp = out[0];
	out[0] = out[1];
	out[1] = temp;

	return (WORD) *out;
}

   
XWORD flipX(XWORD in)
{
	XWORD out = {in.a, in.b, in.c ,in.d};

	return out;
}


XWORD makeX(DWORD conv)
{
	XWORD *in = (XWORD *) &conv;
	XWORD out = {in->a, in->b, in->c ,in->d};

	return out;
}


DWORD makeD(XWORD conv)
{
	DWORD *in = (DWORD *) &conv;
	DWORD out = *in;

	return out;
}*/

