/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


import java.io.*;

//================================================
// class TMyStreamFile
//================================================
public class TMyStreamFile extends TMyPrebufferedFile
{

 //================================================
 //public static abstract interface TStreamProvider
 //================================================
 public static abstract interface TStreamProvider
 {
  public abstract InputStream GetStream() throws Exception;
  public abstract void FreeStream(InputStream stream);
  public abstract void Free();
 }

 private TStreamProvider StreamProvider;
 private int streamPos;
 private InputStream is;
 private int progress = -1;
 private boolean AbortUnpacking;
 private boolean bSupportAbort; //support AbortReadOperation and progress during reading

 //===================================================
 // Constructor
 //===================================================
 public TMyStreamFile(String fileName, TStreamProvider StreamProvider, boolean bSupportAbort) throws Exception
 {
  super(fileName, true);
  //use larger buffer for phones with lot of memory
  //with will also take more chances what while paging ZIP files backwards,
  //stream restart will not be required

  //too big buffer will make reading operations slow

  this.StreamProvider = StreamProvider;
  this.bSupportAbort = bSupportAbort;

  Common.gc();

  try
  {
   is = StreamProvider.GetStream(); //can throw
  }
   catch (Exception e)
  {
//#DEBUG{
   System.out.println("StreamProvider.GetStream() exception="+e.toString()+e.getMessage());
//#DEBUG}
   StreamProvider.Free();
   throw new Exception("");
  }

  streamPos=0;

  Length = is.available(); //can return 0(unknown), 1 (something is  available) or size

  //do not use skip() - skip beyond the file length  crashes Nokia

  if (Length<2)
   {
    //available does not work - sl45i
    try
    {
     int i;
     do
     {
      i = is.read(buffer,0,buffer.length);
      if (i==-1) i=0;
      Length+=i;
     } while (i==buffer.length);
     streamPos=Length;
    }
    catch (Exception e)
    {
//#DEBUG{
     System.out.println("TMyStreamFile() exception during determining file size="+e.toString()+e.getMessage());
//#DEBUG}
     StreamProvider.FreeStream(is);
     StreamProvider.Free();
     throw new Exception("");
    }
   }
 }

 //===================================================
 // .Close();
 //===================================================
 public void Close()
 {
  StreamProvider.FreeStream(is);
  StreamProvider.Free();
  buffer=null;
 }

 //===================================================
 // .getProgress()
 //===================================================
 public int getProgress()
 {
  return progress;
 }

 //===================================================
 // .AbortReadOperation()
 //===================================================
 public void AbortReadOperation()
 {
//  System.out.println("**AbortReadOperation()");

  AbortUnpacking=true;
 }

 //===================================================
 // .SeekStreamToOffset()
 //===================================================
 //called only from Prebuffer()
 //seek stream to specified offset, reopen if necessary
 //corrupts current buffer
 //this can be very slow operation for packed streams
 //operation can be aborted with AbortReadOperation() call
 //in this case method returns immediatelly with false result,
 //and stream is not seeked to specified offset
 private final boolean SeekStreamToOffset(int offset) throws Exception
 {
  AbortUnpacking=false;

  if (streamPos>offset)
   {
    //reopen stream
    StreamProvider.FreeStream(is);
    is = StreamProvider.GetStream(); //can throw
    streamPos=0;
   }

  while (streamPos<offset)
   {
    if (bSupportAbort && AbortUnpacking)
     {
//#DEBUG{
      System.out.println("***Read operation aborted***");
//#DEBUG}
      AbortUnpacking=false;
      progress=-1;
      return false;
     }

//      System.out.println("seeking");

    if (bSupportAbort) progress=(streamPos*Common.MAXPROGRESS)/offset;
    int skipAmount = offset-streamPos;
    streamPos+=is.read(buffer,0,skipAmount<buffer.length ? skipAmount : buffer.length); //can throw
   }
  AbortUnpacking=false;
  progress=-1;
  return true;
 }

 //===================================================
 // .PreBuffer()
 //===================================================
 //fill current buffer so FilePos position if available
 //since seekeng stream back is much slower than seeking forward,
 //prebuffer so current offset is at middle of the buffer
 //reuse data from current buffer, if possible
 //using this heirstic, paging forward/backward will not cause stream reset
 //operatin can be aborted with AbortReadOperation() call
 //if this case method return immediatelly, and buffer if not filled
 protected final boolean PreBuffer()
 {
  int newBufOffset = FilePos-buffer.length/2;
  if (newBufOffset<0) newBufOffset=0;

  int newBufSize = Length - newBufOffset;
  if (newBufSize>buffer.length) newBufSize = buffer.length;

  int offsetToRead=0;          //offset and number of bytes to be updated in current buffer
  int countToRead=newBufSize;  //offset in original file = newBufOffset+offset

  //try to reuse as much as posiible information from current buffer if
  //reading forward. Reading backward will cause stream reset anyway, so
  //just discard whole buffer (we can gain several milliseconds id reuse
  //when pagin backward - less to unpack, but I think it does no worth it).

  if (newBufOffset>=bufferOffset)
   {
    int relativeOffset = newBufOffset-bufferOffset; //offset of new buffer inside old
    int count = bufferSize-relativeOffset; //bytes available
    if (count>0)
     {
      System.arraycopy(buffer,relativeOffset,buffer,0,count);
      offsetToRead=count;
      countToRead=newBufSize-count;
     }
   }

 bufferSize=newBufSize;
 bufferOffset=newBufOffset;

 if (countToRead>0)
   {
    try
     {
      if (SeekStreamToOffset(bufferOffset+offsetToRead)==false)
       {
        //invalidate buffer - it has been corrupted with SeekStreamToOffset()
        InvalidateBuffer();
        return false;
       }

      streamPos+=countToRead;

      //handle streams with partial reads
      while (countToRead>0)
       {
        int i = is.read(buffer,offsetToRead,countToRead);
        offsetToRead+=i;
        countToRead-=i;
       }
     }
     catch (Exception e)
     {
//#DEBUG{
     System.out.println("TMyStreamFile:Prebuffer() exception="+e.toString()+e.getMessage());
//#DEBUG}
      //buffer will be filled with garbage. Left it as is, because
      //full error handling is too complex
     }
   }
  return true;
 }
}
