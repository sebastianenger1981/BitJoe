/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


import java.io.*;
import java.util.*;

//#SIEMENS{

import com.siemens.mp.io.*;

public class TMyMMCFile extends TMyPrebufferedFile
{
 private static File FileClass = new File();

//#ZIP{
 //TMyMMCFile keeps list of all Opened files, so TMyZipFile.readEntries()
 //could reuse opened file for ReadEntries
 //otherwise it will be unable open file sond time
 //element = TMyMMCFile;
 private static Vector OpenedFiles = new Vector(); 
//#ZIP}

 private int f;

 //===================================================
 // ctor
 //===================================================
 private TMyMMCFile(String FileName) throws Exception
 {
  super(FileName,true);
  f=FileClass.open(FileName);
  if (f<0) throw new IOException();
  Length=FileClass.length(f);
  if (Length<0)
   {
    FileClass.close(f);
    throw new IOException();
   }
//#ZIP{  
  OpenedFiles.addElement(this); 
//#ZIP}
 }
 
 //===================================================
 // .Open
 //===================================================
 public static final TMyMMCFile Open(String FileName) throws Exception
 {
  return new TMyMMCFile(FileName);
 }
 

 //===================================================
 // TMyMMCFile.Close();
 //===================================================
 public void Close()
 {
  try
   {
    FileClass.close(f);
   }
  catch(Exception e)
  {
//#DEBUG{   
   System.out.println("TMMYFile.Close() Exception: "+e);
//#DEBUG}
  }
//#ZIP{  
  OpenedFiles.removeElement(this); 
//#ZIP}
 }

 //===================================================
 // TMyMMCFile.PreBuffer()
 //===================================================
 protected boolean PreBuffer()
 {
  bufferOffset = FilePos-buffer.length/2;
  if (bufferOffset<0) bufferOffset=0;

  bufferSize = Length - bufferOffset;
  if (bufferSize>buffer.length) bufferSize = buffer.length;

 if (bufferSize>0)
   {
    try
     {
      FileClass.seek(f,bufferOffset);
      FileClass.read(f,buffer,0,bufferSize);
     }
    catch (Exception e)
     {
//#DEBUG{
      System.out.println("IO error in Prebuffer()");      
//#DEBUG}
      return false; 
     }
   }
  return true; 
 }

 //===================================================
 // TMyMMCFile.Write()
 //===================================================
 //offset - offset in buf
 public int Write(byte[] buf, int offset, int numBytes) throws IOException
 {
  int i=FileClass.seek(f,FilePos);
  if (i<0) throw new IOException();
  i=FileClass.write(f,buf,offset,numBytes);
  if (i<0) throw new IOException();
  if (FilePos==Length) Length+=numBytes;
  FilePos+=numBytes;

  InvalidateBuffer();
  return i;
 }

 //===============================================
 // .Write(int)
 //===============================================
 public void Write(int i) throws IOException
 {
   smallByteArray[0]=(byte) (i & 255);
   smallByteArray[1]=(byte) ((i>>8) & 255);
   smallByteArray[2]=(byte) ((i>>16) & 255);
   smallByteArray[3]=(byte) ((i>>24) & 255);
   Write(smallByteArray,0,4);
 }

 //===============================================
 // .Write(boolean)
 //===============================================
 public void Write(boolean b) throws IOException
 {
   if (b) smallByteArray[0]=1;
     else smallByteArray[0]=0;
   Write(smallByteArray,0,1);
 }

 //===============================================
 // .Write(byte)
 //===============================================
 public void Write(byte b) throws IOException
 {
   smallByteArray[0]=b;
   Write(smallByteArray,0,1);
 }

 //===============================================
 // .Writeln()
 //===============================================
 public void Writeln(String s) throws Exception
 {
  int len=s.length();
  byte[] buf = new byte[len+2];
  System.arraycopy(s.getBytes(),0,buf,0,len);
  buf[len++]=13;
  buf[len++]=10;
  Write(buf,0,len);
 }

 //=================================
 //.Exists()
 //=================================
 public static boolean Exists(String filename)
 {
  boolean res = false;
  try
  {
   res=FileClass.exists(filename)>=0;
  } 
  catch (Exception e)
  {
  }
  return res;
 } 

 //=================================
 //.SpaceAvailable()
 //=================================
 public static int SpaceAvailable()
 {
  int res = 0;
  try
   {
    res = FileClass.spaceAvailable();
   }
  catch (Exception e)
   {
//#DEBUG{
    e.printStackTrace();
//#DEBUG} 
   }
  return res;
 }
 
 //===============================================
 //.InternalEraseFile()
 //===============================================
 static private final void InternalEraseFile(String FileName)
 {
  try
  {
   if (File.exists(FileName)>=0) File.delete(FileName);
  }
   catch (Exception e)
  {
   //do nothing
  }
 }

 //===============================================
 //.EraseFile()
 //===============================================
 public static final void EraseFile(String FileName, boolean eraseIndex)
 {
  InternalEraseFile(FileName);

  if (eraseIndex)
   {
//#ZIP{
    if (TMyZipFile.isZipArchive(FileName))
     {
      //erase indexes of all files from archive
      String[] list = TMyZipFile.List(FileName);
      if (list!=null)
       {
        for (int i=0;i<list.length;i++)
         {
          InternalEraseFile(GetIndexFileName(list[i]));
         }
       }  
     }
      else 
//#ZIP}
     {
      InternalEraseFile(GetIndexFileName(FileName));
     } 
    
    if (TMyTcrFile.isTcrFile(FileName)) 
     {
      InternalEraseFile(TMyTcrFile.GetIdxFileName(FileName));
     }
   } 
 }

 //===============================================
 //public static boolean isAbsolutePath()
 //===============================================
 public static boolean isAbsolutePath(String FileName)
 {
  return FileName.startsWith("a:\\") ||
         FileName.startsWith("A:\\") ||
         FileName.startsWith("4:\\");
 }

 //===============================================
 //public static String GetFilePath()
 //===============================================
 public static String GetFilePath(String FileName)
 {

  int i = FileName.lastIndexOf('\\');
  
  if (isAbsolutePath(FileName))
   {
    //absolute path specified
    return FileName.substring(0,i+1);
   }
    else
   {
    //file is inside storage
    if (i>=0)
     {
      //f.e.  books\1.txt
      return FileName.substring(0,i+1);
     }
      else
     {
      //f.e 1.txt
      return ".";
     }
   }
 }           

 //===================================================
 // .isReadOnly()
 //===================================================
 public boolean isReadOnly()
 {
  return false;
 }

//#ZIP{
 //===================================================
 //TMyMMCFile GetOpenedFile()
 //===================================================
 public static TMyMMCFile GetOpenedFile(String FileName)
 {
  FileName=FileName.toUpperCase();
  for (int i=0;i<OpenedFiles.size(); i++)
   {
    TMyMMCFile mf = (TMyMMCFile)OpenedFiles.elementAt(i);
    if (mf.fileName.toUpperCase().equals(FileName)) 
     {
//#DEBUG{      
//#DEBUG}
      System.out.println("File "+FileName+" reused");
      return mf;
     } 
   }
  return null;
 }
//#ZIP}
}

//#SIEMENS}

//#RMSMMCFILE{
//#RMSMMCFILE:
//#RMSMMCFILE:import javax.microedition.rms.*;
//#RMSMMCFILE:
//#RMSMMCFILE://Recordstore with name "FileList" holds list of all files in the following format:
//#RMSMMCFILE://
//#RMSMMCFILE:// Single record:
//#RMSMMCFILE:// filename          : array [0..31] of byte;  //null-terminated
//#RMSMMCFILE:// fat.recordStoreId : WORD;
//#RMSMMCFILE:// fat.recordId      : DWORD;
//#RMSMMCFILE:// length            : DWORD;
//#RMSMMCFILE://
//#RMSMMCFILE:// "FAT" recordstore holds list of records, allocated for file:
//#RMSMMCFILE:// fat.recordStoreId : WORD;
//#RMSMMCFILE:// fat.recordId      : DWORD;
//#RMSMMCFILE:// count = Length/1024
//#RMSMMCFILE://
//#RMSMMCFILE:// All other records including FATs have names = random WORD
//#RMSMMCFILE:// and size 1024 bytes.
//#RMSMMCFILE:// last record of file can have Length%1024 size
//#RMSMMCFILE:// FAT record has size length/1024
//#RMSMMCFILE:
//#RMSMMCFILE:public class TMyMMCFile extends TMyFile
//#RMSMMCFILE:{
//#RMSMMCFILE: private static final class TRecord
//#RMSMMCFILE: {
//#RMSMMCFILE:  public RecordStore rs;
//#RMSMMCFILE:  public short RecordStoreNameId;
//#RMSMMCFILE:  public int Id;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: private static Vector OpenedFiles = new Vector(); 
//#RMSMMCFILE:
//#RMSMMCFILE: private int FilePos;
//#RMSMMCFILE: private TRecord FileHeader;    //kept opened until file is closed
//#RMSMMCFILE: private TRecord FAT;           //kept opened, updated at end
//#RMSMMCFILE: private TRecord CurrentRecord; //kept opened, updated at end
//#RMSMMCFILE:
//#RMSMMCFILE: private byte[] FATData;  //always holds data
//#RMSMMCFILE:
//#RMSMMCFILE: private int CurrentRecordOffset; //offset of the current record; CurrentRecordOffset%1024=0
//#RMSMMCFILE:
//#RMSMMCFILE: private static int BUFSIZE = 1024;
//#RMSMMCFILE: private byte[] RecBuf = new byte[BUFSIZE];
//#RMSMMCFILE:
//#RMSMMCFILE: private boolean modified; //current buffer is modified and should be saved on close or prebuffer
//#RMSMMCFILE: private boolean HeaderModified; //file length has been modified
//#RMSMMCFILE: private boolean FATModified; //file length has been modified
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .DumpRecordStores()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: static void DumpRecordStores()
//#RMSMMCFILE: {
//#RMSMMCFILE:  System.out.println("-- RMS List ----");
//#RMSMMCFILE:  String[] l = RecordStore.listRecordStores();
//#RMSMMCFILE:
//#RMSMMCFILE:  if (l!=null)
//#RMSMMCFILE:  {
//#RMSMMCFILE:   for (int i=0; i<l.length; i++)
//#RMSMMCFILE:    {
//#RMSMMCFILE:     RecordStore rs = null;
//#RMSMMCFILE:
//#RMSMMCFILE:     try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      System.out.println("RecordStore: "+l[i]);
//#RMSMMCFILE:      rs = RecordStore.openRecordStore(l[i],false);
//#RMSMMCFILE:
//#RMSMMCFILE:      RecordEnumeration enum = rs.enumerateRecords(null,null,false);
//#RMSMMCFILE:      System.out.println("RecordCount: "+enum.numRecords());
//#RMSMMCFILE:
//#RMSMMCFILE:      byte[] data;
//#RMSMMCFILE:      int j = 0;
//#RMSMMCFILE:      while(enum.hasNextElement())
//#RMSMMCFILE:       {
//#RMSMMCFILE:        j++;
//#RMSMMCFILE:        data=enum.nextRecord();
//#RMSMMCFILE:        if (data!=null)
//#RMSMMCFILE:         {
//#RMSMMCFILE:          System.out.println("  Record "+j+"("+data.length+"): "+new String(data,0,data.length));
//#RMSMMCFILE:         }
//#RMSMMCFILE:          else
//#RMSMMCFILE:         {
//#RMSMMCFILE:          System.out.println("  Record "+j+" - null");
//#RMSMMCFILE:         }
//#RMSMMCFILE:       }
//#RMSMMCFILE:      enum.destroy();
//#RMSMMCFILE:     }
//#RMSMMCFILE:      catch (Exception e)
//#RMSMMCFILE:     {
//#RMSMMCFILE:      e.printStackTrace();
//#RMSMMCFILE:     }
//#RMSMMCFILE:     try
//#RMSMMCFILE:      {
//#RMSMMCFILE:       if (rs!=null) rs.closeRecordStore();
//#RMSMMCFILE:      }
//#RMSMMCFILE:     catch (Exception e) {}
//#RMSMMCFILE:    }
//#RMSMMCFILE:  }
//#RMSMMCFILE:  System.out.println("-- RMS List end ---");
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .GetFileHeader()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: //return opened recordstore with record for FileName
//#RMSMMCFILE: private static TRecord GetFileHeader(String FileName)
//#RMSMMCFILE: {
//#DEBUG{
//#RMSMMCFILE:  long StartTime = System.currentTimeMillis();
//#DEBUG} 
//#RMSMMCFILE:
//#RMSMMCFILE:  FileName = FileName.toUpperCase();
//#RMSMMCFILE:  
//#RMSMMCFILE:  TRecord r = new TRecord();
//#RMSMMCFILE:  r.rs = null;
//#RMSMMCFILE:  RecordEnumeration enum = null;
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    r.rs = RecordStore.openRecordStore("FileList",false);
//#RMSMMCFILE:
//#RMSMMCFILE:    enum = r.rs.enumerateRecords(null,null,false);
//#RMSMMCFILE:
//#RMSMMCFILE:    while (enum.hasNextElement())
//#RMSMMCFILE:     {
//#RMSMMCFILE:      r.Id=enum.nextRecordId();
//#RMSMMCFILE:      byte[] data = r.rs.getRecord(r.Id);
//#RMSMMCFILE:
//#RMSMMCFILE:// NameLen           : byte;
//#RMSMMCFILE:// filename          : array [0..31] of byte;  //null-terminated
//#RMSMMCFILE:// fat.recordStoreId : WORD;
//#RMSMMCFILE:// fat.recordId      : DWORD;
//#RMSMMCFILE:// length            : DWORD;
//#RMSMMCFILE:
//#RMSMMCFILE:      if (data!=null &&
//#RMSMMCFILE:            data.length==1+32+2+4+4 &&
//#RMSMMCFILE:            data[0]<=32 &&
//#RMSMMCFILE:            FileName.equals(Common.ByteArrayToString(data,1,data[0])))
//#RMSMMCFILE:             {
//#RMSMMCFILE:              enum.destroy();
//#DEBUG{
//#RMSMMCFILE:              System.out.println("GetFileHeader(sucess)="+(System.currentTimeMillis()-StartTime)+"ms");
//#DEBUG} 
//#RMSMMCFILE:              return r;
//#RMSMMCFILE:             }
//#RMSMMCFILE:     }
//#RMSMMCFILE:
//#RMSMMCFILE:    enum.destroy();
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#DEBUG{    
//#RMSMMCFILE:    System.out.println("Exception in GetFileHeader():");
//#RMSMMCFILE:    e.printStackTrace();
//#DEBUG}    
//#RMSMMCFILE:   }
//#RMSMMCFILE:  if (r.rs!=null)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      r.rs.closeRecordStore();
//#RMSMMCFILE:      r.rs=null;
//#RMSMMCFILE:     }
//#RMSMMCFILE:     catch (Exception e1)
//#RMSMMCFILE:     {
//#RMSMMCFILE:     }
//#RMSMMCFILE:   }
//#RMSMMCFILE:  if (enum!=null)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    try
//#RMSMMCFILE:    {
//#RMSMMCFILE:     enum.destroy();
//#RMSMMCFILE:    }
//#RMSMMCFILE:    catch (Exception e2)
//#RMSMMCFILE:    {
//#RMSMMCFILE:    }
//#RMSMMCFILE:   }
//#DEBUG{
//#RMSMMCFILE:  System.out.println("GetFileHeader(fail)="+(System.currentTimeMillis()-StartTime)+"ms");
//#DEBUG} 
//#RMSMMCFILE:  return null;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .exists()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: static boolean Exists(String FileName_)
//#RMSMMCFILE: {
//#DEBUG{
//#RMSMMCFILE:    Common.gc();  
//#RMSMMCFILE:    System.out.println("Free heap(file.exists)="+Runtime.getRuntime().freeMemory());
//#DEBUG}
//#RMSMMCFILE:
//#RMSMMCFILE:  TRecord FileHeader = GetFileHeader(FileName_);
//#RMSMMCFILE:  if (FileHeader==null) return false;
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FileHeader.rs.closeRecordStore();
//#RMSMMCFILE:    FileHeader.rs=null;
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch(Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:   }
//#RMSMMCFILE:  return true;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //CreateNewRecord()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: private TRecord CreateNewRecord()
//#RMSMMCFILE: {
//#RMSMMCFILE:  //try to and record to any existing recordstore
//#RMSMMCFILE:
//#RMSMMCFILE:  TRecord rec = new TRecord();
//#RMSMMCFILE:
//#RMSMMCFILE:  String[] l = RecordStore.listRecordStores();
//#RMSMMCFILE:
//#RMSMMCFILE:  if (l!=null)
//#RMSMMCFILE:  {
//#RMSMMCFILE:   for (int i=0; i<l.length; i++)
//#RMSMMCFILE:    if (l[i].equals("FileList")==false && 
//#RMSMMCFILE:        l[i].equals("crash")==false)
//#RMSMMCFILE:    {
//#RMSMMCFILE:     rec.rs = null;
//#RMSMMCFILE:     try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      rec.rs = RecordStore.openRecordStore(l[i],false);
//#RMSMMCFILE:      if (rec.rs.getNumRecords()>=50) throw new Exception(); 
//#RMSMMCFILE:       //do not create more than 50 records in single recordstore, or acess will be very slow
//#RMSMMCFILE:      rec.Id = rec.rs.addRecord(null,0,0);
//#RMSMMCFILE:      rec.RecordStoreNameId=Short.parseShort(l[i]);
//#RMSMMCFILE:      return rec;
//#RMSMMCFILE:     }
//#RMSMMCFILE:      catch (Exception e)
//#RMSMMCFILE:     {
//#RMSMMCFILE:      try
//#RMSMMCFILE:       {
//#RMSMMCFILE:        //was unable to add record
//#RMSMMCFILE:        if (rec.rs!=null) rec.rs.closeRecordStore();
//#RMSMMCFILE:       }
//#RMSMMCFILE:      catch (Exception e1) 
//#RMSMMCFILE:       {
//#RMSMMCFILE:       }
//#RMSMMCFILE:     }  
//#RMSMMCFILE:    }
//#RMSMMCFILE:  }
//#RMSMMCFILE:
//#RMSMMCFILE:  //create new unique RecordStore
//#RMSMMCFILE:  rec.rs = null;
//#RMSMMCFILE:  while (rec.rs==null)
//#RMSMMCFILE:  {
//#RMSMMCFILE:   rec.RecordStoreNameId=(short)(System.currentTimeMillis() % 32767);
//#RMSMMCFILE:   String Name = String.valueOf(rec.RecordStoreNameId);
//#RMSMMCFILE:   try
//#RMSMMCFILE:    {
//#RMSMMCFILE:     rec.rs=RecordStore.openRecordStore(Name,false);
//#RMSMMCFILE:     rec.rs.closeRecordStore();
//#RMSMMCFILE:     rec.rs=null;
//#RMSMMCFILE:     continue;
//#RMSMMCFILE:    }
//#RMSMMCFILE:   catch (Exception e)
//#RMSMMCFILE:    {
//#RMSMMCFILE:     try
//#RMSMMCFILE:      {
//#RMSMMCFILE:       rec.rs=RecordStore.openRecordStore(Name,true);
//#RMSMMCFILE:      } 
//#RMSMMCFILE:     catch (Exception e1)
//#RMSMMCFILE:      {
//#RMSMMCFILE:       e1.printStackTrace();  //fatal error
//#RMSMMCFILE:       rec.rs=null;
//#RMSMMCFILE:       return null;
//#RMSMMCFILE:      }
//#RMSMMCFILE:    }
//#RMSMMCFILE:  }
//#RMSMMCFILE:  
//#RMSMMCFILE:  try
//#RMSMMCFILE:  {
//#RMSMMCFILE:   rec.Id=rec.rs.addRecord(null,0,0);
//#RMSMMCFILE:  }
//#RMSMMCFILE:  catch (Exception e)
//#RMSMMCFILE:  {
//#RMSMMCFILE:   //should not happend !
//#RMSMMCFILE:   try
//#RMSMMCFILE:    {
//#RMSMMCFILE:     rec.rs.closeRecordStore();
//#RMSMMCFILE:     rec.rs=null;
//#RMSMMCFILE:    }
//#RMSMMCFILE:     catch (Exception e1)
//#RMSMMCFILE:    {
//#RMSMMCFILE:     e1.printStackTrace();
//#RMSMMCFILE:    }
//#RMSMMCFILE:
//#RMSMMCFILE:   return null;
//#RMSMMCFILE:  }
//#RMSMMCFILE:  return rec;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // .UpdateFileHeader()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: private void UpdateFileHeader() throws Exception
//#RMSMMCFILE: {
//#RMSMMCFILE:// NameLen           : byte;
//#RMSMMCFILE:// filename          : array [0..31] of byte;  //null-terminated
//#RMSMMCFILE:// fat.recordStoreId : WORD;
//#RMSMMCFILE:// fat.recordId      : DWORD;
//#RMSMMCFILE:// length            : DWORD;
//#RMSMMCFILE:
//#RMSMMCFILE:  byte[] b = new byte[1+32+2+4+4];
//#RMSMMCFILE:
//#RMSMMCFILE:  int len = Math.min(32,fileName.length());
//#RMSMMCFILE:
//#RMSMMCFILE:  b[0]=(byte)len;
//#RMSMMCFILE:  System.arraycopy(Common.StringToByteArray(fileName),0,b,1,len);
//#RMSMMCFILE:
//#RMSMMCFILE:  b[1+32]   = (byte)(FAT.RecordStoreNameId >> 8);
//#RMSMMCFILE:  b[1+32+1] = (byte)(FAT.RecordStoreNameId % 256);
//#RMSMMCFILE:
//#RMSMMCFILE:  b[1+32+2]   = (byte)(FAT.Id >> 24);
//#RMSMMCFILE:  b[1+32+2+1] = (byte)((FAT.Id >> 16) & 255);
//#RMSMMCFILE:  b[1+32+2+2] = (byte)((FAT.Id >> 8) & 255);
//#RMSMMCFILE:  b[1+32+2+3] = (byte)(FAT.Id & 255);
//#RMSMMCFILE:
//#RMSMMCFILE:  b[1+32+2+4]   = (byte)(Length >> 24);
//#RMSMMCFILE:  b[1+32+2+4+1] = (byte)((Length >> 16) & 255);
//#RMSMMCFILE:  b[1+32+2+4+2] = (byte)((Length >> 8) & 255);
//#RMSMMCFILE:  b[1+32+2+4+3] = (byte)(Length & 255);
//#RMSMMCFILE:
//#RMSMMCFILE:  FileHeader.rs.setRecord(FileHeader.Id,b,0,1+32+2+4+4);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // ctor
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: private TMyMMCFile(String FileName_) throws Exception
//#RMSMMCFILE: {
//#RMSMMCFILE:  super(FileName_.toUpperCase());
//#RMSMMCFILE://  DumpRecordStores();
//#RMSMMCFILE:  FilePos=0;
//#RMSMMCFILE:
//#RMSMMCFILE:  FileHeader = GetFileHeader(fileName);
//#RMSMMCFILE:
//#RMSMMCFILE:  FAT=null;
//#RMSMMCFILE:
//#RMSMMCFILE:  if (FileHeader!=null)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    try
//#RMSMMCFILE:    {
//#RMSMMCFILE:     //get length and FAT
//#RMSMMCFILE:     byte[] b = FileHeader.rs.getRecord(FileHeader.Id);
//#RMSMMCFILE:     
//#RMSMMCFILE:     if (b==null || b.length!=1+32+2+4+4) throw new Exception();
//#RMSMMCFILE:
//#RMSMMCFILE:     FAT=new TRecord();
//#RMSMMCFILE:
//#RMSMMCFILE:     FAT.RecordStoreNameId = (short)(((b[1+32] & 0xff) << 8)  +  (b[1+32+1] & 0xff));
//#RMSMMCFILE:
//#RMSMMCFILE:     FAT.Id = (int)(((b[1+32+2] & 0xff)<<24)+
//#RMSMMCFILE:                   ((b[1+32+2+1] & 0xff)<<16)+
//#RMSMMCFILE:                   ((b[1+32+2+2] & 0xff)<<8)+
//#RMSMMCFILE:                   ((b[1+32+2+3] & 0xff)));
//#RMSMMCFILE:
//#RMSMMCFILE:     Length = (int)(((b[1+32+2+4] & 0xff)<<24)+
//#RMSMMCFILE:                   ((b[1+32+2+4+1] & 0xff)<<16)+
//#RMSMMCFILE:                   ((b[1+32+2+4+2] & 0xff)<<8)+
//#RMSMMCFILE:                   ((b[1+32+2+4+3] & 0xff)));
//#RMSMMCFILE:
//#RMSMMCFILE:     FAT.rs=RecordStore.openRecordStore(String.valueOf(FAT.RecordStoreNameId),false);
//#RMSMMCFILE:
//#RMSMMCFILE:     FATData = FAT.rs.getRecord(FAT.Id);
//#RMSMMCFILE:     
//#RMSMMCFILE:     if (FATData==null) 
//#RMSMMCFILE:      {
//#RMSMMCFILE:       FATData = new byte[0];
//#RMSMMCFILE:      } 
//#RMSMMCFILE:     if ((Length+1023)/1024*6!=FATData.length) throw new Exception();
//#RMSMMCFILE:    }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:    {
//#DEBUG{
//#RMSMMCFILE:     System.out.println("Exception when opening existing file:");
//#RMSMMCFILE:     e.printStackTrace();
//#RMSMMCFILE:
//#RMSMMCFILE:     System.out.println("Fileheader or FAT is corrupter for file: "+fileName);
//#RMSMMCFILE:     System.out.println("Trying to recover");
//#DEBUG}     
//#RMSMMCFILE:     try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      if (FAT!=null) FAT.rs.closeRecordStore();
//#RMSMMCFILE:     }
//#RMSMMCFILE:      catch (Exception e1)
//#RMSMMCFILE:     {
//#RMSMMCFILE:     } 
//#RMSMMCFILE:
//#RMSMMCFILE:     try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      if (FileHeader!=null) 
//#RMSMMCFILE:       {
//#RMSMMCFILE:        FileHeader.rs.closeRecordStore();
//#RMSMMCFILE:       } 
//#RMSMMCFILE:     }
//#RMSMMCFILE:      catch (Exception e1)
//#RMSMMCFILE:     {
//#RMSMMCFILE:     } 
//#RMSMMCFILE:     EraseFile(fileName,false);
//#RMSMMCFILE:    }
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  if (FileHeader==null)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FileHeader = new TRecord();
//#RMSMMCFILE:    FileHeader.Id=-1;
//#RMSMMCFILE:    FileHeader.rs=null;
//#RMSMMCFILE:    try
//#RMSMMCFILE:    {
//#RMSMMCFILE:     //create new file
//#RMSMMCFILE:     FileHeader.rs = RecordStore.openRecordStore("FileList",true); //can throw
//#RMSMMCFILE:     
//#RMSMMCFILE:     if (FileHeader.rs.getSizeAvailable()<2000) 
//#RMSMMCFILE:      {
//#DEBUG{
//#RMSMMCFILE:       System.out.println("Too low space to create file");
//#DEBUG}
//#RMSMMCFILE:       FileHeader.rs.closeRecordStore();
//#RMSMMCFILE:       FileHeader.rs=null;
//#RMSMMCFILE:       throw new Exception("No free space to create file "+fileName);
//#RMSMMCFILE:      } 
//#RMSMMCFILE:
//#RMSMMCFILE:     FileHeader.Id=FileHeader.rs.addRecord(null,0,0); //can throw
//#RMSMMCFILE:
//#RMSMMCFILE:     Length=0;
//#RMSMMCFILE:
//#RMSMMCFILE:     FAT=CreateNewRecord();
//#RMSMMCFILE:
//#RMSMMCFILE:     FATData = new byte[0];
//#RMSMMCFILE:
//#RMSMMCFILE:     UpdateFileHeader(); //can throw
//#RMSMMCFILE:    }
//#RMSMMCFILE:     catch (Exception e)
//#RMSMMCFILE:    {
//#DEBUG{
//#RMSMMCFILE:     System.out.println("Exception when creating new file:");
//#RMSMMCFILE:     e.printStackTrace();
//#DEBUG}     
//#RMSMMCFILE:     try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      if (FileHeader!=null) 
//#RMSMMCFILE:       {
//#RMSMMCFILE:        if (FileHeader.Id!=-1)
//#RMSMMCFILE:         {
//#RMSMMCFILE:          FileHeader.rs.deleteRecord(FileHeader.Id);
//#RMSMMCFILE:         }
//#RMSMMCFILE:        FileHeader.rs.closeRecordStore();
//#RMSMMCFILE:       } 
//#RMSMMCFILE:     }
//#RMSMMCFILE:      catch (Exception e1)
//#RMSMMCFILE:     {
//#RMSMMCFILE:     } 
//#RMSMMCFILE:     try
//#RMSMMCFILE:      {
//#RMSMMCFILE:       if (FAT!=null) 
//#RMSMMCFILE:        {
//#RMSMMCFILE:         FAT.rs.deleteRecord(FAT.Id);
//#RMSMMCFILE:         FAT.rs.closeRecordStore();
//#RMSMMCFILE:        } 
//#RMSMMCFILE:      }
//#RMSMMCFILE:     catch (Exception e2)
//#RMSMMCFILE:      {
//#RMSMMCFILE:      }
//#RMSMMCFILE:     throw new IOException("No free space to create file "+fileName);
//#RMSMMCFILE:    }
//#RMSMMCFILE:   }
//#RMSMMCFILE:  
//#RMSMMCFILE:  CurrentRecord = new TRecord();
//#RMSMMCFILE:  CurrentRecord.rs=null;
//#RMSMMCFILE:
//#RMSMMCFILE:  modified=false;
//#RMSMMCFILE:  FATModified=false;
//#RMSMMCFILE:  HeaderModified=false;
//#RMSMMCFILE:  
//#RMSMMCFILE:  OpenedFiles.addElement(this);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // .Open
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public static final TMyMMCFile Open(String FileName) throws Exception
//#RMSMMCFILE: {
//#RMSMMCFILE:  return new TMyMMCFile(FileName);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //TMyMMCFile.Update()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: private void Update()
//#RMSMMCFILE: {
//#RMSMMCFILE:  try
//#RMSMMCFILE:  {
//#RMSMMCFILE:   //assert(CurrentRecord.rs!=null);
//#RMSMMCFILE:   CurrentRecord.rs.setRecord(CurrentRecord.Id,RecBuf,0,Math.min(1024,Length-CurrentRecordOffset));
//#RMSMMCFILE:  }
//#RMSMMCFILE:  catch (Exception e)
//#RMSMMCFILE:  {
//#DEBUG{
//#RMSMMCFILE:   System.out.println("Unable to update record:");
//#RMSMMCFILE:   e.printStackTrace();
//#DEBUG}
//#RMSMMCFILE:  }
//#RMSMMCFILE:  modified=false;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //TMyMMCFile.UpdateFAT()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: private void UpdateFAT()
//#RMSMMCFILE: {
//#RMSMMCFILE:  try
//#RMSMMCFILE:  {
//#RMSMMCFILE:   //assert(CurrentRecord.rs!=null);
//#RMSMMCFILE:   FAT.rs.setRecord(FAT.Id,FATData,0,(Length+1023)/1024*6);
//#RMSMMCFILE:  }
//#RMSMMCFILE:  catch (Exception e)
//#RMSMMCFILE:  {
//#DEBUG{
//#RMSMMCFILE:   System.out.println("Unable to update FAT:");
//#RMSMMCFILE:   e.printStackTrace();
//#DEBUG}
//#RMSMMCFILE:  }
//#RMSMMCFILE:  FATModified=false;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //TMyMMCFile.Close();
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public void Close()
//#RMSMMCFILE: {
//#RMSMMCFILE:  if (modified) Update();
//#RMSMMCFILE:  
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    if (HeaderModified) UpdateFileHeader();
//#RMSMMCFILE:   }
//#RMSMMCFILE:  catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:   }
//#RMSMMCFILE:   
//#RMSMMCFILE:  if (FATModified) UpdateFAT();
//#RMSMMCFILE:  
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    if (CurrentRecord.rs!=null) CurrentRecord.rs.closeRecordStore();
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    e.printStackTrace();
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FAT.rs.closeRecordStore();
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    e.printStackTrace();
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FileHeader.rs.closeRecordStore();
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    e.printStackTrace();
//#RMSMMCFILE:   }
//#RMSMMCFILE:   
//#RMSMMCFILE:  fileName=null; 
//#RMSMMCFILE:  FileHeader.rs=null;
//#RMSMMCFILE:  FileHeader=null;
//#RMSMMCFILE:  FAT.rs=null;
//#RMSMMCFILE:  FAT=null;
//#RMSMMCFILE:  CurrentRecord.rs=null;
//#RMSMMCFILE:  CurrentRecord=null;
//#RMSMMCFILE:  RecBuf=null;
//#RMSMMCFILE:  OpenedFiles.removeElement(this);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // TMyMMCFile.Prebuffer()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: private void PreBuffer()
//#RMSMMCFILE: {
//#RMSMMCFILE:  if (modified) Update();
//#RMSMMCFILE:  
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    if (CurrentRecord.rs!=null) CurrentRecord.rs.closeRecordStore();
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  CurrentRecordOffset = (FilePos/1024)*1024;
//#RMSMMCFILE:
//#RMSMMCFILE:  CurrentRecord.rs=null;
//#RMSMMCFILE:  if (FilePos==Length) return;
//#RMSMMCFILE:
//#RMSMMCFILE:  int offset = (FilePos/1024)*6;
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    if (FATData.length<offset+6) throw new Exception();
//#RMSMMCFILE:
//#RMSMMCFILE:    CurrentRecord.RecordStoreNameId = (short)(((FATData[offset] & 0xff)<<8) + ((FATData[offset+1] & 0xff)));
//#RMSMMCFILE:    CurrentRecord.Id = ((FATData[offset+2] & 0xff)<<24) +
//#RMSMMCFILE:                        ((FATData[offset+2+1] & 0xff)<<16) +
//#RMSMMCFILE:                        ((FATData[offset+2+2] & 0xff)<<8) +
//#RMSMMCFILE:                        ((FATData[offset+2+3] & 0xff));
//#RMSMMCFILE:
//#RMSMMCFILE:    CurrentRecord.rs=RecordStore.openRecordStore(String.valueOf(CurrentRecord.RecordStoreNameId),false);
//#RMSMMCFILE:    byte[] data = CurrentRecord.rs.getRecord(CurrentRecord.Id);
//#RMSMMCFILE:    System.arraycopy(data,0,RecBuf,0,data.length);
//#RMSMMCFILE:   }
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    CurrentRecord.rs=null;
//#RMSMMCFILE:    RecBuf=new byte[1024];
//#RMSMMCFILE:    for (int i=0;i<1024;i++) RecBuf[i]=0;
//#RMSMMCFILE:   }
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // TMyMMCFile.Read()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public int Read(byte[] DestBuf, int offset, int numBytes)
//#RMSMMCFILE: {
//#RMSMMCFILE:  if (CurrentRecord.rs==null || FilePos<CurrentRecordOffset ||
//#RMSMMCFILE:      FilePos>=CurrentRecordOffset+1024)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        PreBuffer();
//#RMSMMCFILE:       }
//#RMSMMCFILE:
//#RMSMMCFILE:  if (FilePos+numBytes>Length)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    numBytes = Length-FilePos;
//#RMSMMCFILE:    if (numBytes<=0) return 0;
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  int len = Math.min(numBytes,CurrentRecordOffset+1024-FilePos);
//#RMSMMCFILE:
//#RMSMMCFILE:  System.arraycopy(RecBuf,FilePos-CurrentRecordOffset,DestBuf,offset,len);
//#RMSMMCFILE:
//#RMSMMCFILE:  FilePos+=len;
//#RMSMMCFILE:
//#RMSMMCFILE:  if (numBytes>len)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    return len+Read(DestBuf,offset+len,numBytes-len);
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  return len;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //TMyMMCFile.ReadSingleByte()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public boolean ReadSingleByte(byte[] DestBuf, int offset)
//#RMSMMCFILE: {
//#RMSMMCFILE:  //fix invalid reads
//#RMSMMCFILE:  if (FilePos>Length-1) return false;
//#RMSMMCFILE:
//#RMSMMCFILE:  if (CurrentRecord.rs==null || FilePos<CurrentRecordOffset ||
//#RMSMMCFILE:      FilePos>=CurrentRecordOffset+1024)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        PreBuffer();
//#RMSMMCFILE:       }
//#RMSMMCFILE:
//#RMSMMCFILE:  DestBuf[offset]=RecBuf[FilePos - CurrentRecordOffset];
//#RMSMMCFILE:  FilePos++;
//#RMSMMCFILE:  return true;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //TMyMMCFile.ReadSingleByteReverse()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public boolean ReadSingleByteReverse(byte[] DestBuf, int offset)
//#RMSMMCFILE: {
//#RMSMMCFILE:  //fix invalid reads
//#RMSMMCFILE:  if (FilePos==0) return false;
//#RMSMMCFILE:
//#RMSMMCFILE:  if (CurrentRecord.rs==null || FilePos<CurrentRecordOffset ||
//#RMSMMCFILE:      FilePos>=CurrentRecordOffset+1024)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        PreBuffer();
//#RMSMMCFILE:       }
//#RMSMMCFILE:
//#RMSMMCFILE:  DestBuf[offset]=RecBuf[FilePos - CurrentRecordOffset];
//#RMSMMCFILE:  FilePos--;
//#RMSMMCFILE:  return true;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // TMyMMCFile.ReadByte()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public byte ReadByte() throws IOException
//#RMSMMCFILE: {
//#RMSMMCFILE:  //fix invalid reads
//#RMSMMCFILE:  if (FilePos>Length-1) return 0;
//#RMSMMCFILE:
//#RMSMMCFILE:  if (CurrentRecord.rs==null || FilePos<CurrentRecordOffset ||
//#RMSMMCFILE:      FilePos>=CurrentRecordOffset+1024)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        PreBuffer();
//#RMSMMCFILE:       }
//#RMSMMCFILE:
//#RMSMMCFILE:  FilePos++;
//#RMSMMCFILE:  return RecBuf[FilePos - CurrentRecordOffset-1];
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // TMyMMCFile.Write()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //offset - offset in buf
//#RMSMMCFILE: public int Write(byte[] buf, int offset, int numBytes) throws IOException
//#RMSMMCFILE: {
//#RMSMMCFILE://  System.out.println("Write="+numBytes);
//#RMSMMCFILE:  if (CurrentRecord.rs==null || FilePos<CurrentRecordOffset ||
//#RMSMMCFILE:      FilePos>=CurrentRecordOffset+1024)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        PreBuffer();
//#RMSMMCFILE:       }
//#RMSMMCFILE:
//#RMSMMCFILE:  if (CurrentRecord.rs==null)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    //FilePos==FileLength
//#RMSMMCFILE:    //CurrentRecordOffset = FilePos is set in Prebuffer, should be %1024=0
//#RMSMMCFILE:    CurrentRecord = CreateNewRecord();
//#RMSMMCFILE:    //update FAT
//#RMSMMCFILE:    FATModified=true;
//#RMSMMCFILE:    int FAToffset = (FilePos/1024)*6;
//#RMSMMCFILE:
//#RMSMMCFILE:    if (FATData.length<FAToffset+6)
//#RMSMMCFILE:     {
//#RMSMMCFILE:      //allocate 1.5 times more memory
//#RMSMMCFILE:      byte[] b = new byte[Math.max(100*6,FATData.length*3/2)];
//#RMSMMCFILE:      System.arraycopy(FATData,0,b,0,FATData.length);
//#RMSMMCFILE:      FATData=b;
//#RMSMMCFILE:     }
//#RMSMMCFILE:
//#RMSMMCFILE:    FATData[FAToffset] = (byte)(CurrentRecord.RecordStoreNameId >> 8);
//#RMSMMCFILE:    FATData[FAToffset+1] = (byte)(CurrentRecord.RecordStoreNameId & 255);
//#RMSMMCFILE:
//#RMSMMCFILE:    FATData[FAToffset+2] = (byte)((CurrentRecord.Id >> 24) & 255);
//#RMSMMCFILE:    FATData[FAToffset+2+1] = (byte)((CurrentRecord.Id >> 16) & 255);
//#RMSMMCFILE:    FATData[FAToffset+2+2] = (byte)((CurrentRecord.Id >> 8) & 255);
//#RMSMMCFILE:    FATData[FAToffset+2+3] = (byte)(CurrentRecord.Id & 255);
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  int len = Math.min(numBytes,CurrentRecordOffset+1024-FilePos);
//#RMSMMCFILE:  System.arraycopy(buf,offset,RecBuf,FilePos-CurrentRecordOffset,len);
//#RMSMMCFILE:
//#RMSMMCFILE:  FilePos+=len;
//#RMSMMCFILE:
//#RMSMMCFILE:  if (FilePos>Length)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    Length=FilePos;
//#RMSMMCFILE:    HeaderModified=true;
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  modified=true;
//#RMSMMCFILE:  if (len<numBytes)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    return len+Write(buf,offset+len,numBytes-len);
//#RMSMMCFILE:   }
//#RMSMMCFILE:  return numBytes;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .Write(int)
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: public void Write(int i) throws IOException
//#RMSMMCFILE: {
//#RMSMMCFILE:  byte[] buf = new byte[4];
//#RMSMMCFILE:  buf[0]=(byte) (i & 255);
//#RMSMMCFILE:  buf[1]=(byte) ((i>>8) & 255);
//#RMSMMCFILE:  buf[2]=(byte) ((i>>16) & 255);
//#RMSMMCFILE:  buf[3]=(byte) ((i>>24) & 255);
//#RMSMMCFILE:  Write(buf,0,4);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .Write(boolean)
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: public void Write(boolean b) throws IOException
//#RMSMMCFILE: {
//#RMSMMCFILE:  byte[] buf = new byte[1];
//#RMSMMCFILE:  if (b) buf[0]=1;
//#RMSMMCFILE:    else buf[0]=0;
//#RMSMMCFILE:  Write(buf,0,1);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .Write(byte)
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: public void Write(byte b) throws IOException
//#RMSMMCFILE: {
//#RMSMMCFILE:  byte[] buf = new byte[1];
//#RMSMMCFILE:  buf[0]=b;
//#RMSMMCFILE:  Write(buf,0,1);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .Writeln()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: public void Writeln(String s) throws IOException
//#RMSMMCFILE: {
//#RMSMMCFILE:  int len=s.length();
//#RMSMMCFILE:  byte[] buf = new byte[len+2];
//#RMSMMCFILE:  System.arraycopy(Common.StringToByteArray(s),0,buf,0,len);
//#RMSMMCFILE:  
//#RMSMMCFILE:  buf[len++]=13;
//#RMSMMCFILE:  buf[len++]=10;
//#RMSMMCFILE:  Write(buf,0,len);
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .spaceAvailable()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: static int SpaceAvailable()
//#RMSMMCFILE: {
//#RMSMMCFILE:  try
//#RMSMMCFILE:  {
//#RMSMMCFILE://   long l = System.currentTimeMillis();
//#RMSMMCFILE:   RecordStore rs = RecordStore.openRecordStore("sizetest",true);
//#RMSMMCFILE:   int i = rs.getSizeAvailable();
//#RMSMMCFILE:   rs.closeRecordStore();
//#RMSMMCFILE:   rs.deleteRecordStore("sizetest");
//#RMSMMCFILE://   l=System.currentTimeMillis()-l;
//#RMSMMCFILE://   System.out.println("time = "+l);
//#RMSMMCFILE:   return i;
//#RMSMMCFILE:  }
//#RMSMMCFILE:   catch (Exception e)
//#RMSMMCFILE:  {
//#RMSMMCFILE:   /*
//#RMSMMCFILE:  MIDlet1.Canvas.DrawMessage(e.getClass()+e.getMessage(),1);
//#RMSMMCFILE:
//#RMSMMCFILE:   */
//#DEBUG{
//#RMSMMCFILE:   e.printStackTrace();
//#DEBUG}
//#RMSMMCFILE:   return 0;
//#RMSMMCFILE:  }
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // .FilePos()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public int FilePos()
//#RMSMMCFILE: {
//#RMSMMCFILE:  return FilePos;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // .Seek()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public void Seek(int pos)
//#RMSMMCFILE: {
//#RMSMMCFILE:  if (pos>Length) pos=Length;
//#RMSMMCFILE:  if (pos<0) 
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FilePos=0;
//#RMSMMCFILE:   }
//#RMSMMCFILE:    else
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FilePos=pos;
//#RMSMMCFILE:   }
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .GoBack()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: //seek back n bytes
//#RMSMMCFILE: public void GoBack(int n)
//#RMSMMCFILE: {
//#RMSMMCFILE:  if (FilePos>=n)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FilePos-=n;
//#RMSMMCFILE:   }
//#RMSMMCFILE:    else
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FilePos=0;
//#RMSMMCFILE:   }
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .InternalEraseFile
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: private final static void InternalEraseFile(String FileName)
//#RMSMMCFILE: {
//#RMSMMCFILE:  TRecord FileHeader = GetFileHeader(FileName);
//#RMSMMCFILE:  
//#RMSMMCFILE:  if (FileHeader==null) return;
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    byte[] b = FileHeader.rs.getRecord(FileHeader.Id);
//#RMSMMCFILE:    FileHeader.rs.deleteRecord(FileHeader.Id);
//#RMSMMCFILE:    FileHeader.rs.closeRecordStore();
//#RMSMMCFILE:
//#RMSMMCFILE:    TRecord FAT = new TRecord(); 
//#RMSMMCFILE:    FAT.RecordStoreNameId = (short)(((b[1+32] & 0xff) << 8)  +  (b[1+32+1] & 0xff));
//#RMSMMCFILE:
//#RMSMMCFILE:    FAT.Id = (int)(((b[1+32+2] & 0xff)<<24)+
//#RMSMMCFILE:                   ((b[1+32+2+1] & 0xff)<<16)+
//#RMSMMCFILE:                   ((b[1+32+2+2] & 0xff)<<8)+
//#RMSMMCFILE:                   ((b[1+32+2+3] & 0xff)));
//#RMSMMCFILE:
//#RMSMMCFILE:    int Length = (int)(((b[1+32+2+4] & 0xff)<<24)+
//#RMSMMCFILE:                      ((b[1+32+2+4+1] & 0xff)<<16)+
//#RMSMMCFILE:                      ((b[1+32+2+4+2] & 0xff)<<8)+
//#RMSMMCFILE:                      ((b[1+32+2+4+3] & 0xff)));
//#RMSMMCFILE:    b=null;                  
//#RMSMMCFILE:
//#RMSMMCFILE:    FAT.rs=RecordStore.openRecordStore(String.valueOf(FAT.RecordStoreNameId),false);
//#RMSMMCFILE:    byte[] FATData = FAT.rs.getRecord(FAT.Id);
//#RMSMMCFILE:    FAT.rs.deleteRecord(FAT.Id);
//#RMSMMCFILE:    FAT.rs.closeRecordStore();
//#RMSMMCFILE:    
//#RMSMMCFILE://    int count = (Length+1023)/1024;
//#RMSMMCFILE:    int count;
//#RMSMMCFILE:    if (FATData==null) 
//#RMSMMCFILE:     {
//#RMSMMCFILE:      count=0;
//#RMSMMCFILE:     }
//#RMSMMCFILE:      else
//#RMSMMCFILE:     { 
//#RMSMMCFILE:      count=FATData.length/6;
//#RMSMMCFILE:     } 
//#RMSMMCFILE:    
//#RMSMMCFILE:    TRecord CurrentRecord = new TRecord();
//#RMSMMCFILE:    //closeRecordStore after deletion is very slow. need to reuse opened recordstores, 
//#RMSMMCFILE:    //because records are likely to be in the same recordstore
//#RMSMMCFILE:    
//#RMSMMCFILE:    CurrentRecord.rs=null;
//#RMSMMCFILE:
//#RMSMMCFILE:    for (int i=0;i<count;i++)
//#RMSMMCFILE:     {
//#RMSMMCFILE:      int offset=i*6;
//#RMSMMCFILE:      short rsNameId = (short)(((FATData[offset] & 0xff)<<8) + ((FATData[offset+1] & 0xff)));
//#RMSMMCFILE:
//#RMSMMCFILE:      if (CurrentRecord.rs!=null && CurrentRecord.RecordStoreNameId!=rsNameId)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        try
//#RMSMMCFILE:         {
//#RMSMMCFILE:          CurrentRecord.rs.closeRecordStore();
//#RMSMMCFILE:         }
//#RMSMMCFILE:         catch (Exception e)
//#RMSMMCFILE:         {
//#RMSMMCFILE:         }
//#RMSMMCFILE:       }
//#RMSMMCFILE:      CurrentRecord.RecordStoreNameId=rsNameId; 
//#RMSMMCFILE:      CurrentRecord.Id = ((FATData[offset+2] & 0xff)<<24) +
//#RMSMMCFILE:                         ((FATData[offset+2+1] & 0xff)<<16) +
//#RMSMMCFILE:                         ((FATData[offset+2+2] & 0xff)<<8) +
//#RMSMMCFILE:                         ((FATData[offset+2+3] & 0xff));
//#RMSMMCFILE:
//#RMSMMCFILE:      try
//#RMSMMCFILE:       {
//#RMSMMCFILE:        if (CurrentRecord.rs==null) 
//#RMSMMCFILE:         {
//#RMSMMCFILE:          CurrentRecord.rs=RecordStore.openRecordStore(String.valueOf(CurrentRecord.RecordStoreNameId),false);
//#RMSMMCFILE:         } 
//#RMSMMCFILE:        CurrentRecord.rs.deleteRecord(CurrentRecord.Id);
//#RMSMMCFILE:       }
//#RMSMMCFILE:       catch (Exception e)
//#RMSMMCFILE:       {
//#RMSMMCFILE:       }
//#RMSMMCFILE:
//#RMSMMCFILE:     }
//#RMSMMCFILE:    if (CurrentRecord.rs!=null)
//#RMSMMCFILE:    {
//#RMSMMCFILE:     CurrentRecord.rs.closeRecordStore();
//#RMSMMCFILE:    } 
//#RMSMMCFILE:   } 
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#DEBUG{
//#RMSMMCFILE:    System.out.println("Exception whle erasing file");
//#RMSMMCFILE:    e.printStackTrace();
//#DEBUG}
//#RMSMMCFILE:   }
//#RMSMMCFILE: }
//#RMSMMCFILE: 
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: //.EraseFile()
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: public static final void EraseFile(String FileName, boolean eraseIndex)
//#RMSMMCFILE: {
//#RMSMMCFILE:  InternalEraseFile(FileName);
//#RMSMMCFILE:
//#RMSMMCFILE:  if (eraseIndex)
//#RMSMMCFILE:   {
//#ZIP{
//#RMSMMCFILE:    if (TMyZipFile.isZipArchive(FileName))
//#RMSMMCFILE:     {
//#RMSMMCFILE:      //erase indexes of all files from archive
//#RMSMMCFILE:      String[] list = TMyZipFile.List(FileName);
//#RMSMMCFILE:      if (list!=null)
//#RMSMMCFILE:       {
//#RMSMMCFILE:        for (int i=0;i<list.length;i++)
//#RMSMMCFILE:         {
//#RMSMMCFILE:          InternalEraseFile(GetIndexFileName(list[i]));
//#RMSMMCFILE:         }
//#RMSMMCFILE:       }  
//#RMSMMCFILE:     }
//#RMSMMCFILE:      else 
//#ZIP}
//#RMSMMCFILE:     {
//#RMSMMCFILE:      InternalEraseFile(GetIndexFileName(FileName));
//#RMSMMCFILE:     } 
//#RMSMMCFILE:    
//#RMSMMCFILE:    if (TMyTcrFile.isTcrFile(FileName)) 
//#RMSMMCFILE:     {
//#RMSMMCFILE:      InternalEraseFile(TMyTcrFile.GetIdxFileName(FileName));
//#RMSMMCFILE:     }
//#RMSMMCFILE:   } 
//#RMSMMCFILE: }
//#RMSMMCFILE: 
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: // .CreateFileList
//#RMSMMCFILE: //===============================================
//#RMSMMCFILE: public static int CreateFileList(String[] FileList,int MAXFILES)
//#RMSMMCFILE: {
//#RMSMMCFILE:  int count=0;
//#RMSMMCFILE:  
//#RMSMMCFILE:  RecordStore rs = null;
//#RMSMMCFILE:  RecordEnumeration enum = null;
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    rs = RecordStore.openRecordStore("FileList",false);
//#RMSMMCFILE:
//#RMSMMCFILE:    enum = rs.enumerateRecords(null,null,false);
//#RMSMMCFILE:
//#RMSMMCFILE:    while (enum.hasNextElement())
//#RMSMMCFILE:     {
//#RMSMMCFILE:      byte[] data = enum.nextRecord();
//#RMSMMCFILE:
//#RMSMMCFILE:// NameLen           : byte;
//#RMSMMCFILE:// filename          : array [0..31] of byte;  //null-terminated
//#RMSMMCFILE:// fat.recordStoreId : WORD;
//#RMSMMCFILE:// fat.recordId      : DWORD;
//#RMSMMCFILE:// length            : DWORD;
//#RMSMMCFILE:
//#RMSMMCFILE:      if (data!=null && data.length==1+32+2+4+4)
//#RMSMMCFILE:           {
//#RMSMMCFILE:            FileList[count] = Common.ByteArrayToString(data,1,data[0]).toUpperCase();
//#RMSMMCFILE:            if (Common.isHiddenFile(FileList[count])==false)
//#RMSMMCFILE:                 {
//#RMSMMCFILE:                  count++;
//#RMSMMCFILE:                 } 
//#RMSMMCFILE:           } 
//#RMSMMCFILE:
//#RMSMMCFILE:     }
//#RMSMMCFILE:   } 
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#DEBUG{    
//#RMSMMCFILE:    System.out.println("Exception during CreateFileList:");
//#RMSMMCFILE:    e.printStackTrace();
//#DEBUG}
//#RMSMMCFILE:   }
//#RMSMMCFILE:  
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    if (enum!=null) enum.destroy();
//#RMSMMCFILE:   }
//#RMSMMCFILE:   catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:   }
//#RMSMMCFILE:
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    if (rs!=null) rs.closeRecordStore(); 
//#RMSMMCFILE:   }
//#RMSMMCFILE:   catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:   }
//#RMSMMCFILE:   
//#RMSMMCFILE:  return count;
//#RMSMMCFILE: } 
//#RMSMMCFILE: 
//#RMSMMCFILE: //=============================================
//#RMSMMCFILE: //=============================================
//#RMSMMCFILE: //true if already exists
//#RMSMMCFILE: static boolean CreateCrashRecord()
//#RMSMMCFILE: {
//#RMSMMCFILE:  try
//#RMSMMCFILE:   {
//#RMSMMCFILE:    RecordStore r = RecordStore.openRecordStore("crash",false);
//#RMSMMCFILE:    r.closeRecordStore();
//#RMSMMCFILE://    System.out.println("crash record exists");
//#RMSMMCFILE:    return true;
//#RMSMMCFILE:   } 
//#RMSMMCFILE:    catch (Exception e)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      RecordStore r = RecordStore.openRecordStore("crash",true);
//#RMSMMCFILE:      r.closeRecordStore();
//#RMSMMCFILE://      System.out.println("crash record created");
//#RMSMMCFILE:     } 
//#RMSMMCFILE:     catch (Exception e1)
//#RMSMMCFILE:     {
//#RMSMMCFILE://      System.out.println("Unable to create crashr record");
//#RMSMMCFILE:     };
//#RMSMMCFILE:    return false;
//#RMSMMCFILE:   }
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //=============================================
//#RMSMMCFILE: //=============================================
//#RMSMMCFILE: static void DeleteCrashRecord()
//#RMSMMCFILE: {
//#RMSMMCFILE:  try
//#RMSMMCFILE:  {
//#DEBUG{   
//#RMSMMCFILE:   System.out.println("Deleting Crash record...");
//#DEBUG}
//#RMSMMCFILE:   RecordStore.deleteRecordStore("crash");
//#DEBUG{   
//#RMSMMCFILE:   System.out.println("Crash record deleted");
//#DEBUG}
//#RMSMMCFILE:  }
//#RMSMMCFILE:  catch (Exception e) {;};
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //=============================================
//#RMSMMCFILE: //=============================================
//#RMSMMCFILE: public static void EraseAll()
//#RMSMMCFILE: {
//#RMSMMCFILE:  String[] list = RecordStore.listRecordStores();
//#RMSMMCFILE:  if (list==null) return;
//#RMSMMCFILE:  
//#RMSMMCFILE:  for (int i =0; i<list.length; i++) 
//#RMSMMCFILE:   {
//#RMSMMCFILE:    try
//#RMSMMCFILE:     {
//#RMSMMCFILE:      RecordStore.deleteRecordStore(list[i]); 
//#RMSMMCFILE:     }
//#RMSMMCFILE:      catch (Exception e) {;}
//#RMSMMCFILE:   }  
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: // .isReadOnly()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public boolean isReadOnly()
//#RMSMMCFILE: {
//#RMSMMCFILE:  return true;
//#RMSMMCFILE: }
//#RMSMMCFILE:
//#ZIP{
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: //TMyMMCFile GetOpenedFile()
//#RMSMMCFILE: //===================================================
//#RMSMMCFILE: public static TMyMMCFile GetOpenedFile(String FileName)
//#RMSMMCFILE: {
//#RMSMMCFILE:  FileName=FileName.toUpperCase();
//#RMSMMCFILE:  for (int i=0;i<OpenedFiles.size(); i++)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    TMyMMCFile mf = (TMyMMCFile)OpenedFiles.elementAt(i);
//#RMSMMCFILE:    if (mf.fileName.toUpperCase().equals(FileName)) 
//#RMSMMCFILE:     {
//#DEBUG{      
//#DEBUG}
//#RMSMMCFILE:      System.out.println("File "+FileName+" reused");
//#RMSMMCFILE:      return mf;
//#RMSMMCFILE:     } 
//#RMSMMCFILE:   }
//#RMSMMCFILE:  return null;
//#RMSMMCFILE: }
//#ZIP}
//#RMSMMCFILE: 
//#RMSMMCFILE:}
//#RMSMMCFILE:
//#RMSMMCFILE}

