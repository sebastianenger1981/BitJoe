/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


//===================================
// class TMyPartialFIle
//===================================
//decorator pattern
//implements TMyFile interface, reading data from part of existing file
//class delegates method calls to source file, adjusting for partial content
//note: only partially implemeted
public class TMyPartialFile extends TMyFile
{
 private TMyFile sourceFile;
 private int sourceOffset;
 private int sourceLength;

 //================================================= 
 // ctor
 //================================================= 
 private TMyPartialFile(TMyFile sourceFile, int sourceOffset, int sourceLength) throws Exception
 {
  super("partialfile:"+sourceFile.fileName);
  if (sourceOffset+sourceLength>sourceFile.Length) 
   {
    sourceFile.Close();
    throw new Exception();
   } 
  
  this.sourceFile=sourceFile;
  this.sourceOffset=sourceOffset;
  this.sourceLength=sourceLength;
  Length=sourceLength;
  sourceFile.Seek(sourceOffset);
 }
 
 //===================================================
 // .Open()
 //===================================================
 public static final TMyPartialFile Open(TMyFile sourceFile, int sourceOffset, int sourceLength) throws Exception
 {
  return new TMyPartialFile(sourceFile, sourceOffset, sourceLength);
 }
 
 //===================================================
 // .Close();
 //===================================================
 public void Close()
 {
  sourceFile.Close();
  sourceFile=null;
 }

 //===================================================
 //.FilePos()
 //===================================================
 public int FilePos()
 {
  return sourceFile.FilePos()-sourceOffset;
 }
 
 //===================================================
 // .AdjustReadLength()
 //===================================================
 private final int AdjustReadLength(int numBytes)
 {
  return java.lang.Math.min(numBytes,Length-FilePos());
 }

 //===================================================
 // .AdjustFilePos()
 //===================================================
 private final void AdjustFilePos()
 {
  if (FilePos()>Length)
   {
    sourceFile.Seek(sourceOffset+sourceLength);
   }
 }

 //===================================================
 // .Read()
 //===================================================
 public int Read(byte[] DestBuf, int offset, int numBytes)
 {
  numBytes=AdjustReadLength(numBytes);
  return sourceFile.Read(DestBuf,offset,numBytes);
 }

 //===================================================
 // .ReadSingleByte()
 //===================================================
 public boolean ReadSingleByte(byte[] DestBuf, int offset)
 {
  if (Length-FilePos()>0)
   {
    return sourceFile.ReadSingleByte(DestBuf,offset);
   }
    else
   {
    return false;
   }
 }

 //===================================================
 // .ReadSingleByteReverse()
 //===================================================
 public boolean ReadSingleByteReverse(byte[] DestBuf, int offset)
 {
  if (FilePos()>0)
   {
    return sourceFile.ReadSingleByte(DestBuf,offset);
   }
    else
   {
    return false;
   }
 }

 //===================================================
 // ReadByte()
 //===================================================
 public byte ReadByte() throws Exception
 {
  if (Length-FilePos()>0)
   {
    return sourceFile.ReadByte();
   }
    else
   {
    return 0;
   }
 }

 //===================================================
 // TMyMMCFile.Seek()
 //===================================================
 public void Seek(int pos)
 {
  if (pos>Length) pos=Length;
  if (pos<0) pos=0;
  sourceFile.Seek(sourceOffset+pos);
  return;
 }

 //===============================================
 // .GoBack()
 //===============================================
 //seek back n bytes
 public void GoBack(int n)
 {
  int pos = FilePos()-n;
  if (pos<0) pos=0;
  sourceFile.Seek(sourceOffset+pos);
 }
 
 
}