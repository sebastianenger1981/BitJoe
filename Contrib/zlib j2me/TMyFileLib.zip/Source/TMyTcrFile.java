/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


import java.util.*;

//===============================================
// class TMyTcrFile
//===============================================
public class TMyTcrFile extends TMyPrebufferedFile
{
 private final static int  HDR1 = 0x2d382121;
 private final static int  HDR2 = 0x21746942;
 private final static int  HDR3 = 0x21;

 private final static int INDEX_FREQ   = 4096;

 private final static int cBUFSIZE    = 256; 
 private byte[] cBuf = new byte[cBUFSIZE];

 private TMyFile sourceFile;

 private int cStreamStartOffset;
 private boolean needReindex;
 private int progress=-1;
 private boolean mustAbortIndexing;

 private byte[][] dictionary = new byte[256][];
 
 private int[] fileIndex; 
 //fileIndex keeps uncompressed file offset for every INDEX_FREQ*n offset of compressed stream
 //given reqired offset, method will find nearest offset in index and walk
 //from it to required offset

 //===================================================
 // .GetIdxFileName
 //===================================================
 public static final String GetIdxFileName(String FileName)
 {
  //use '.idy' extension for simplicity...
  String idxFileName = TMyFile.GetIndexFileName(FileName);
  return idxFileName.substring(0,idxFileName.length()-1)+'y';
 }

 //===================================================
 // .LoadIndex()
 //===================================================
 private final boolean LoadIndex()
 {
  boolean res=true;
  
  TMyFile idxFile = null;
  try
  {
   idxFile = TMyMMCFile.Open(GetIdxFileName(fileName));
   if (idxFile.ReadInt()!=sourceFile.Length) throw new Exception();
   Length=idxFile.ReadInt();

   int cStreamLen = sourceFile.Length-cStreamStartOffset;
   int recCount = (cStreamLen+INDEX_FREQ-1)/INDEX_FREQ;
   
   if (idxFile.Length!=4+4+4+4*recCount) throw new Exception();

   if (idxFile.ReadInt()!=recCount) throw new Exception();

   fileIndex = new int[recCount];

   for (int i=0; i<recCount; i++)
    {
     fileIndex[i]=idxFile.ReadInt();
    }
  }
  catch (Exception e)
  {
   res=false;
//#DEBUG{
   System.out.println("Valid TCR Index not found");
//#DEBUG}
  }
  
  if (idxFile!=null) idxFile.Close();
  
  return res;
 }

 //===================================================
 // .SaveIndex()
 //===================================================
 private final void SaveIndex()
 {
  TMyFile idxFile = null;
  try
  {
   int cStreamLen = sourceFile.Length-cStreamStartOffset;
   int recCount = (cStreamLen+INDEX_FREQ-1)/INDEX_FREQ;
   
   int requiredSpace = recCount*4+4+100;
   
   if (TMyMMCFile.SpaceAvailable()<requiredSpace) throw new Exception();

   idxFile = TMyMMCFile.Open(GetIdxFileName(fileName));
   idxFile.Write(sourceFile.Length);
   idxFile.Write(Length);
   idxFile.Write(recCount);
   for (int i=0; i<recCount; i++)
    {
     idxFile.Write(fileIndex[i]);
    }
  }
  catch (Exception e)
  {
  }
  
  if (idxFile!=null) idxFile.Close();
 }

 //===================================================
 // .BuildIndex()
 //===================================================
 //build index and find out file length
 //should be called with sourceFile seeked to the start of stream
 public void BuildIndex()
 {
  Common.gc();

  int cStreamLen = sourceFile.Length-cStreamStartOffset;
  int recCount = (cStreamLen+INDEX_FREQ-1)/INDEX_FREQ;

  fileIndex = new int[recCount];
  
  Length=0;
  mustAbortIndexing=false;
  for (int i=0; i<recCount;i++)
   {
    progress = i*Common.MAXPROGRESS/recCount;
    
//    Common.sleep(100);
    
    fileIndex[i]=Length; 
    
    int rc = INDEX_FREQ;

    while(rc>0)
     {
      int len = rc>buffer.length?buffer.length:rc;
    
      int count = sourceFile.Read(buffer,0,len);

      if (count==0) break;
      rc-=count;
    
      for (int j=0; j<count; j++)
       {
        int code = buffer[j] & 0xff;
        if (dictionary[code]!=null) Length+=dictionary[code].length;
       }
      if (mustAbortIndexing) return;
     }  
   }
  SaveIndex(); 
  progress=-1; 
 }

 //===================================================
 // Constructor
 //===================================================
 private TMyTcrFile(TMyFile sourceFile) throws Exception
 {
  super(sourceFile.fileName,true);
  this.sourceFile = sourceFile;

  //check header
  int hdr1=sourceFile.ReadInt();
  int hdr2=sourceFile.ReadInt();
  int hdr3=sourceFile.ReadByte();

  if (hdr1!=HDR1 || hdr2!=HDR2 || hdr3!=HDR3) throw new Exception();

  //read dictionary

  for (int i=0; i<256;i++)
   {
    int len = sourceFile.ReadByte() & 0xff;
    if (len>0)
     {
      dictionary[i]=new byte[len];
      sourceFile.Read(dictionary[i],0,len);
     }
      else
     {
      dictionary[i]=null;
     }
   }

  cStreamStartOffset=sourceFile.FilePos();
  
  Common.gc();

  Length=0;

  needReindex = LoadIndex()==false;
 }

 //====================================================
 // .isTcrFile()
 //====================================================
 public static final boolean isTcrFile(String FileName)
 {
  return FileName.toUpperCase().endsWith(".TCR");
 }

 //===================================================
 // .Open()
 //===================================================
 public static final TMyFile Open(String FileName) throws Exception
 {
  TMyFile srcFile = TMyMMCFile.Open(FileName);

  try
   {
    return new TMyTcrFile(srcFile);
   }
   catch (Exception e)
   {
    //got exception - wrong format
    srcFile.Close();
    return TMyFile.OpenFile("resource:res/badformat.txt");
   }
 }


 //===================================================
 // .Close();
 //===================================================
 public void Close()
 {
  sourceFile.Close();
 }

 //===================================================
 // .SeekCStream()
 //===================================================
 //seek compressed stream as close to the offset as possible
 //overshot should be max 256 bytes
 private final int SeekCStream(int offset) throws Exception
 {
  //search for nearest offset in index

  //binary search
  int top=fileIndex.length-1;
  int bottom=0;
    
  while (top!=bottom)
   {
    int middle = (top+bottom)/2;

    if (offset<fileIndex[middle])
     {
      top=middle;
     }
      else //if (offset>=fileIndex[middle])
     {
      if (bottom==middle)
       {
        top=bottom;
       }
        else
       {
        bottom=middle;
       }
     }
   }
   
//System.out.println("required offset="+offset);
//System.out.println("found offset="+fileIndex[top]);

 sourceFile.Seek(INDEX_FREQ*top+cStreamStartOffset); 
 int state_FilePos=fileIndex[top];

//  int state_FilePos=0;  
//  sourceFile.Seek(cStreamStartOffset);
  
  for(;;)
   {
    if (state_FilePos==offset) return state_FilePos; //handle offset=0 case
    
    int startOffset = sourceFile.FilePos();
    
    sourceFile.Read(cBuf,0,cBUFSIZE);
    
    for (int i=0; i<cBUFSIZE; i++)
     {
      int code = cBuf[i] & 0xff;
      if (dictionary[code]!=null) state_FilePos+=dictionary[code].length;
      if (state_FilePos>=offset)
       {
        sourceFile.Seek(startOffset+i+1);  
        return state_FilePos;
       }
     } 
   }

   //will newer get here
//  return 0;
 }

 //===================================================
 // .Prebuffer()
 //===================================================
 protected final boolean PreBuffer()
 {
  bufferOffset = FilePos-buffer.length/2;
  if (bufferOffset<0) bufferOffset=0;
  
  try
   {
    bufferOffset=SeekCStream(bufferOffset);

    bufferSize = Length - bufferOffset;
    if (bufferSize>buffer.length) bufferSize = buffer.length;
    
    int count=0;
    
    for (;;)
     {
      sourceFile.Read(cBuf,0,cBUFSIZE);
      
      for (int i=0; i<cBUFSIZE;i++)
       {
        int code = cBuf[i] & 0xff;

        if (dictionary[code]!=null)
         {
          int len = dictionary[code].length;
          if (count+len>bufferSize)
           {
            bufferSize=count;
            return true;
           }
          System.arraycopy(dictionary[code],0,buffer,count,len); 
          count+=len;
         }
         
       } //for i
     } //for(;;)
   }
    catch (Exception e)
   {
//#DEBUG{
    System.out.println("Unable to read/decode tcr file");
    e.printStackTrace();
//#DEBUG}
   }
   
  return false;  
 }

 //===================================================
 // .getProgress();
 //===================================================
 public int getProgress()
 {
  return progress;
 }

 //===============================================
 //.isNeedReindex()
 //===============================================
 public boolean isNeedReindex()
 {
  return needReindex; 
 }

 //===================================================
 // .AbortReadOperation();
 //===================================================
 public void AbortReadOperation()
 {
  mustAbortIndexing=true;
 }
 
}
