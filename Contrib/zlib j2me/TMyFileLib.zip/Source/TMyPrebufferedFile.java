/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


import java.io.*;

//=============================================
// class TMyPrebufferedFile
//=============================================
//presents a strategy for handling files with prebuffering
//introduces template method Prebuffer()
public abstract class TMyPrebufferedFile extends TMyFile
{
 protected int bufferOffset;
 protected int bufferSize;
 protected byte[] buffer;
 
 protected int FilePos;

 //=========================================
 // InvalidateBufer()
 //=========================================
 protected void InvalidateBuffer()
 {
  bufferSize=0;
 }

 //=========================================
 // ctor
 //=========================================
 protected TMyPrebufferedFile(String fileName, boolean doAlocateBuffer) throws Exception
 {
  super(fileName);
  
  if (doAlocateBuffer)
   {
    Common.gc();
//SIEMENS{    
    buffer = new byte[Runtime.getRuntime().totalMemory()>300000? 4096 : 1024];
//SIEMENS}
//#MIDP10{
//#MIDP10:    buffer = new byte[Runtime.getRuntime().totalMemory()>300000? 4096 : 512];
//#MIDP10}
   } 
  InvalidateBuffer();
  FilePos=0;
 }

 //===================================================
 // .FilePos()
 //===================================================
 public int FilePos()
 {
  return FilePos;
 }

 //===================================================
 // .Seek()
 //===================================================
 public void Seek(int pos)
 {
  if (pos>Length) pos=Length;
  if (pos<0)
   {
    FilePos=0;
   }
    else
   {
    FilePos=pos;
   }
 }

 //===============================================
 //.GoBack()
 //===============================================
 public void GoBack(int n)
 {
  if (FilePos>=n)
   {
    FilePos-=n;
   }
    else
   {
    FilePos=0;
   }
 }

 //===================================================
 // .PreBuffer()
 //===================================================
 //template method
 //fill current buffer so at least one byte at FilePos position is available
 //operatin can be aborted with AbortReadOperation() call
 //if this case method return immediatelly, and buffer if not filled
 //read() methods will return failure
 protected abstract boolean PreBuffer();
 
 //===================================================
 // .Read()
 //===================================================
 public int Read(byte[] DestBuf, int offset, int numBytes)
 {
  //fix invalid reads
  if (FilePos+numBytes>Length) numBytes=Length-FilePos;

  if (numBytes==0) return 0;

  if (FilePos>=bufferOffset && FilePos<bufferOffset+bufferSize)
   {
    //read all available data
    int len=bufferOffset+bufferSize-FilePos;
    if (len>=numBytes)
     {
      System.arraycopy(buffer,FilePos-bufferOffset,DestBuf,offset,numBytes);
      FilePos+=numBytes;
      return numBytes;
     }
      else
     {
      System.arraycopy(buffer,FilePos-bufferOffset,DestBuf,offset,len);
      FilePos+=len;
      PreBuffer();
      return len+Read(DestBuf,offset+len,numBytes-len);
     }
   }
    else
   {
    PreBuffer();
    return Read(DestBuf,offset,numBytes);
   }
 }

 //===================================================
 // .ReadSingleByte()
 //===================================================
 public boolean ReadSingleByte(byte[] DestBuf, int offset)
 {
  //fix invalid reads
  if (FilePos>=Length) return false;

  boolean b = true;
  if (!(FilePos>=bufferOffset && FilePos<bufferOffset+bufferSize)) b=PreBuffer();

  DestBuf[offset]=buffer[FilePos-bufferOffset];
  FilePos++;
  return b;
 }

 //===================================================
 // .ReadSingleByteReverse()
 //===================================================
 public boolean ReadSingleByteReverse(byte[] DestBuf, int offset)
 {
  //fix invalid reads
  if (FilePos==0) return false;

  FilePos--;
  boolean b = true;
  if (!(FilePos>=bufferOffset && FilePos<bufferOffset+bufferSize)) b=PreBuffer();

  DestBuf[offset]=buffer[FilePos-bufferOffset];
  return b;
 }

 //===================================================
 // .ReadByte()
 //===================================================
 public byte ReadByte() throws IOException
 {
  //fix invalid reads
  if (FilePos>=Length) return 0;

  if (!(FilePos>=bufferOffset && FilePos<bufferOffset+bufferSize)) PreBuffer();

  byte b = buffer[FilePos-bufferOffset];
  FilePos++;
  return b;
 }

}
