/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


//=========================================
// public class TMyPalmDocFile
//=========================================
//decorator for TMyFile
public class TMyPalmDocFile extends TMyPrebufferedFile
{
 private final static int PDBTYPEID_TEXt = 0x54455874; // 'TEXt'
 
 //database ID for HandStory reader
 private final static int CREATORID_HandStory = 0x68734942; // 'hsIB'
 //database ID for TealDoc PilotDoc reader
 private final static int CREATORID_TealDoc = 0x546c4463; // 'TlDc'
 //database ID for generic PilotDoc reader
 private final static int CREATORID_Reader = 0x52454164; // 'REAd'

 private final static short DOCVERSION_UNCOMPRESSED = 1;
 private final static short DOCVERSION_COMPRESSED = 2;
 
 private final static int COUNT_BITS = 3;
 private final static int SHIFTED_COUNT_BITS_MINUS_1 = ((1 << COUNT_BITS) - 1);
 
 private TMyFile sourceFile;
 private int[] RecordOffset;
 private boolean compressed;
 private int recordSize; //each uncompressed record has this size (except last)

 //===================================================
 // Constructor
 //===================================================
 private TMyPalmDocFile(TMyFile sourceFile) throws Exception
 {
  super(sourceFile.fileName,false);
  this.sourceFile = sourceFile;
  
  //read dbheader

  //skip name(32) 
  //attribute(2) 
  //version(2) 
  //creationDate(4)  
  //modificationDate(4)
  //lastBackupDate(4)
  //modificationNumber(4)
  //appInfoID(4)
  //sortInfoID(4)
  sourceFile.Seek(32+2+2+4+4+4+4+4+4); 
 
  int typeID = Common.ReverceByteOrder(sourceFile.ReadInt());
  int creatorId = Common.ReverceByteOrder(sourceFile.ReadInt());
  Common.ReverceByteOrder(sourceFile.ReadInt()); //skip uniqueIDSeed
  Common.ReverceByteOrder(sourceFile.ReadInt()); //skip nextRecordListID
  int numRecords = Common.ReverceByteOrder(sourceFile.ReadWord()<<16);

  if(typeID!=PDBTYPEID_TEXt || 
      (creatorId!=CREATORID_HandStory &&
       creatorId!=CREATORID_TealDoc &&
       creatorId!=CREATORID_Reader) ||
      numRecords>1000 || 
      numRecords==0)  
      {
       throw new Exception();
      }

  RecordOffset = new int[numRecords];

  for (int i=0;i<numRecords;i++)
   {
    RecordOffset[i] = Common.ReverceByteOrder(sourceFile.ReadInt());
    sourceFile.ReadInt(); //skip other attributes
   }

  sourceFile.Seek(RecordOffset[0]);

  int docVersion = Common.ReverceByteOrder(sourceFile.ReadWord()<<16);
  sourceFile.ReadWord(); //spare ???
  Length = Common.ReverceByteOrder(sourceFile.ReadInt());
  sourceFile.ReadWord(); //numRecords ??? redundant
  recordSize = Common.ReverceByteOrder(sourceFile.ReadWord()<<16);
 
  if ((docVersion!=DOCVERSION_UNCOMPRESSED && docVersion!=DOCVERSION_COMPRESSED) ||
    recordSize<1 ||
    recordSize>16000 ||
    Length<1 ||
    Length>10000000)
     {
      throw new Exception();
     } 
 
  compressed=docVersion==DOCVERSION_COMPRESSED;

  Common.gc();
  buffer = new byte[recordSize];
 }

 //====================================================
 // .isPalmDocFile()
 //====================================================
 public static final boolean isPalmDocFile(String FileName)
 {
  String s = FileName.toUpperCase();
  return s.endsWith(".PDB") || s.endsWith(".PRC");
 }
 
 //===================================================
 // .Open()
 //===================================================
 public static final TMyFile Open(String FileName) throws Exception
 {
  TMyFile srcFile = TMyMMCFile.Open(FileName); //do not used TMyFile.Openfile - will recursivelly call self !
  
  try
   {
    return new TMyPalmDocFile(srcFile);
   }
   catch (Exception e)
   {
    //got exception - wrong format
    srcFile.Close();
    return TMyFile.OpenFile("resource:res/badformat.txt");
   }
 }

 //===================================================
 // .Close();
 //===================================================
 public void Close()
 {
  sourceFile.Close(); 
 }

 //===================================================
 // .PreBuffer()
 //===================================================
 protected final boolean PreBuffer()
 {
  int recordIndex = FilePos/recordSize;
  bufferOffset=recordIndex*recordSize;
  recordIndex++; //starting from 1
  
  bufferSize = Length-bufferOffset;
  if (bufferSize>recordSize) bufferSize=recordSize;
  
  int cBufSize;
  
  if (recordIndex==RecordOffset.length-1)
   {
    cBufSize=sourceFile.Length-RecordOffset[recordIndex];
   }
    else
   {
    cBufSize=RecordOffset[recordIndex+1]-RecordOffset[recordIndex];
   }
   
  if (cBufSize>16000 || cBufSize<1)
   {
//#DEBUG{
    System.out.println("Invalid compressed record size:"+cBufSize);
//#DEBUG}
    return false;
   }
   
  byte[] cBuf;
  if (compressed)
   {
    Common.gc();
    cBuf = new byte[cBufSize];//essential for sl45i
   } 
    else
   {
    //ignore errors
    cBufSize=bufferSize;
    cBuf=buffer;
   }

  try
  {
   sourceFile.Seek(RecordOffset[recordIndex]);
   sourceFile.Read(cBuf,0,cBufSize);
  }
   catch (Exception e)
  {
//#DEBUG{
    System.out.println("Unable to read pbd file");
//#DEBUG}
    return false;
  }

  if (compressed==false) return true;

  try
  {
   int inIndex = 0;
   int destIndex = 0;
   
   for (;inIndex<cBufSize;)
    {
     int c = cBuf[inIndex++] & 0xff;
     // separate the char into zones: 0, 1...8, 9...0x7F, 0x80...0xBF, 0xC0...0xFF
     // codes 1...8 mean copy that many bytes; for accented chars & binary
     if(c > 0 && c < 9) 
      {
       System.arraycopy(cBuf, inIndex, buffer, destIndex, c);
       inIndex += c;
       destIndex += c;
      }
     else if(c < 0x80) // codes 0, 9...0x7F represent themselves
     {
      buffer[destIndex++] = (byte) c;
     }
      else if(c >= 0xC0) // codes 0xC0...0xFF represent "space + ascii char"
     {
      buffer[destIndex++] = (byte) ' ';
      buffer[destIndex++] = (byte) (c ^ 0x80);
     }
     else // codes 0x80...0xBf represent sequences
     {
      c = (c << 8) | cBuf[inIndex++] & 0xff;

      int distance = (c & 0x3fff) >> COUNT_BITS;
      int length = (c & SHIFTED_COUNT_BITS_MINUS_1) + 3;

      while(length-- > 0) 
       {
        buffer[destIndex] = buffer[destIndex - distance];
        destIndex++;
       }
     } //elsse
    }//for
  } //try
  catch (Exception e)
  {
   //invalid compressed data
//#DEBUG{
    System.out.println("invalid compressed data");
    return false;
//#DEBUG}
  }
  return true;
 }

}
