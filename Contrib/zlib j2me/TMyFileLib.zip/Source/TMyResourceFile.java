/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


import java.io.*;

//===================================== 
// TMyResourceFile
//=====================================  
public final class TMyResourceFile
{
 //============================== 
 // TResourceStreamProvider 
 //==============================
 private static final class TResourceStreamProvider implements TMyStreamFile.TStreamProvider
 {
  private String resFileName;
  
  //resFileName will be used directly in OpenResource()
  TResourceStreamProvider(String resFileName)
  {
   this.resFileName=resFileName;
  }
  
  public final InputStream GetStream() throws Exception
  {
//#DEBUG{
   System.out.println("Open resource file: "+resFileName);
//#DEBUG}

//#SIEMENS{
   return javax.microedition.io.Connector.openInputStream(resFileName);
//#SIEMENS}

//#MIDP10{
//#MIDP10:   return Common.GetResourceStream(resFileName);
//#MIDP10} 
  }
  
  public final void FreeStream(InputStream stream)
  {
   try
   {
    stream.close();
   }
   catch (Exception e)
   {
//#DEBUG{
    System.out.println("Exception in TResourceStreamProvider::CloseStream() = "+e.toString()+e.getMessage());
//#DEBUG} 
   }
  }
  
  public final void Free()
  {
   //do nothing
  }
 }

 //===================================================
 //.Open()
 //===================================================
 public static final TMyStreamFile Open(String FileName) throws Exception
 {
//#SIEMENS{
  return new TMyStreamFile(FileName, new TResourceStreamProvider(FileName), false);
//#SIEMENS}

//#MIDP10{  
//#MIDP10:  return new TMyStreamFile(FileName,new TResourceStreamProvider(FileName.substring(9)),false);
//#MIDP10}
 }
 
 //===================================================
 //public static boolean IsResourceFile()
 //===================================================
 public static final boolean IsResourceFile(String FileName)
 {
  return FileName.startsWith("resource:");
 } 

 //===================================================
 // .getProgress()
 //===================================================
 public int getProgress()
 {
  return -1; //do not show any progress for resource files
  //acess is relatively fast anyway
 }

}
