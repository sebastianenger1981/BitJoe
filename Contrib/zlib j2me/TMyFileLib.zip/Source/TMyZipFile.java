/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


//#ZIP{
import java.util.*;
import java.io.*;
import com.asoft.midp.zip.*;


//============================================
// TMyZipFile
//============================================
public class TMyZipFile
{
 /* The central directory file header */
 private static final int CENSIG = 'P'|('K'<<8)|(1<<16)|(2<<24);
 private static final int CENHDR = 46;

 /* The entries in the end of central directory */
 private static final int ENDSIG = 'P'|('K'<<8)|(5<<16)|(6<<24);
 private static final int ENDHDR = 22;

 private static final int LOCSIG = 'P'|('K'<<8)|(3<<16)|(4<<24);

 //============  ZipFileEntry  ==============
 private static final class TZipEntry
 {
  public String FileName;
  public int offset;
  public int Length;
  public int csize;
  public int method;

  TZipEntry(String FileName, int offset, int Length, int csize, int method)
  {
   this.FileName=new String(FileName);
   this.offset=offset;
   this.Length=Length;
   this.csize=csize;
   this.method=method;
  }
 }

 //============  TDecompressorStream  ==============
 private static final class TDecompressorStream extends InputStream
 {
  private static final int BUFSIZE = 4096;

  private TMyFile compressedFile;
  private int uncompressedSize;
  private Inflater decompressor;

  private byte[] onebytebuffer = new byte[1];
  private byte [] buf = new byte[BUFSIZE];

  //----------------------------
  TDecompressorStream(TMyFile compressedFile, int uncompressedSize) throws Exception
  {
   this.compressedFile=compressedFile;
   this.uncompressedSize=uncompressedSize;

   System.out.println("creating inflater...");

   try
   {
    compressedFile.Seek(0);
    decompressor=new Inflater(true);
    decompressor.reset();
    fill();
   }
    catch (Exception e)
   {
    throw new Exception(e.getMessage());
   }
   System.out.println("creating inflater ok");
  }

  //----------------------------
  public void close()
  {
   decompressor.end();
  }

  //----------------------------
  public int available()
  {
   return uncompressedSize-decompressor.getTotalOut();
  }

  //----------------------------
  public int read() throws IOException
  {
   int nread = read(onebytebuffer, 0, 1); //read one byte

   if (nread > 0) return onebytebuffer[0] & 0xff;

   return -1;
  }

  //----------------------------
  private final void fill() throws Exception
  {
   int len = compressedFile.Read(buf, 0, buf.length);

   if (len < 0) throw new Exception("Deflated stream ends early.");

   decompressor.setInput(buf, 0, len);
  }

  //----------------------------
  public int read(byte[] b, int off, int len) throws IOException
  {
   if (len == 0) return 0;

//#DEBUG{
//   System.out.println("Decompressing...");
   long waitTime = System.currentTimeMillis();
//#DEBUG}

   int totalCount=0;

   for (;;)
    {
     int count = 0;

     try
      {
//       System.out.println("totalout="+decompressor.getTotalOut());
       count = decompressor.inflate(b, off, len);
      }
     catch (Exception e)
      {
//#DEBUG{
       System.out.println("Got exception="+e.toString()+" "+e.getMessage());
//#DEBUG}
      }

     len-=count;
     totalCount+=count;
     off+=count;

     if (len==0)
      {
//#DEBUG{
       System.out.println("Decompressed "+totalCount+" bytes, pos="+decompressor.getTotalOut()+
         ", time="+(System.currentTimeMillis()-waitTime)+"ms");
//#DEBUG}
       return totalCount;
      }

     if (decompressor.needsDictionary() | decompressor.finished()) return 0;

     if (decompressor.needsInput())
      {
//       System.out.println("NeedsInput");
       try
        {
         fill();
        }
        catch (Exception e)
        {
//#DEBUG{
         System.out.println("TSrreamFile.fill - Got exception="+e.toString()+" "+e.getMessage());
//#DEBUG}
        }
      }

     if (decompressor.needsInput()==false && count==0)
      {
       throw new IOException("Don't know what to do");
      }
    }
  }

/*
 //skip is never used anyway...
  //----------------------------
  //provide Skip, because default skip reads by single byte...
  public long skip(long n) throws Exception
  {
   if (n < 0) throw new IllegalArgumentException();

   if (n == 0) return 0;

  final int buflen = n > 2048 ? 2048 : (int) n;
   byte[] tmpbuf = new byte[buflen];
   final long origN = n;

   while (n > 0L)
    {
     int numread = read(tmpbuf, 0, n > buflen ? buflen : (int) n);
     if (numread <= 0) break;
     n -= numread;
    }
   return origN - n;
  }
*/
 }

 //========== TDecompressorStreamProvider ========================
 private static class TDecompressorStreamProvider implements TMyStreamFile.TStreamProvider
 {
  TMyFile cstreamFile;
  private int uncompressedSize;

  //----------------------------
  TDecompressorStreamProvider(TMyFile cstreamFile, int uncompressedSize)
  {
   this.cstreamFile=cstreamFile;
   this.uncompressedSize=uncompressedSize;
  }

  //----------------------------
  public InputStream GetStream() throws Exception
  {
   return new TDecompressorStream(cstreamFile,uncompressedSize);
  }

  //----------------------------
  public void FreeStream(InputStream stream)
  {
   try
    {
     stream.close();
    }
     catch (Exception e)
    {
//#DEBUG{
     System.out.println("TZipStreamProvider:FreeStream() exception="+e.toString()+e.getMessage());
//#DEBUG}
    }

  }

  //----------------------------
  public void Free()
  {
   cstreamFile.Close();
  }
 }


 //====================================================
 // constructor
 //====================================================
 TMyZipFile()
 {
 }

 //====================================================
 // boolean isZipArchive()
 //====================================================
 //FileName = zipfile:a:\\javaj\asimov.zip
 public static final boolean isZipArchive(String FileName)
 {
  return FileName.toUpperCase().endsWith(".ZIP");
 }

 //====================================================
 // boolean isZipFile()
 //====================================================
 //FileName = zipfile:a:\\javaj\asimov.zip,book1\voyage.txt
 public static final boolean isZipFile(String FileName)
 {
  return FileName.startsWith("zipfile:");
 }

 //====================================================
 // .CheckLocalRecord()
 //====================================================
 private static final int CheckLocalRecord(String ZipFileName, TZipEntry entry) throws Exception
 {
  TMyFile sourceFile = TMyFile.OpenFile(ZipFileName);

  try
  {
   if (entry.offset+entry.csize>sourceFile.Length) throw new Exception("Not enought compressed data");
   sourceFile.Seek(entry.offset);

   int sign = sourceFile.ReadInt();
   if (sign!=LOCSIG) throw new Exception("invalid local signature");

   int pos = entry.offset+4+2+2;
   sourceFile.Seek(pos);

   if (entry.method!=sourceFile.ReadWord()) throw new Exception("compression metod mismatch");

   pos+=2+2+2+4+4+4;
   sourceFile.Seek(pos);

   int FileNameLength = sourceFile.ReadWord();
   if (entry.FileName.length()!=FileNameLength) throw new Exception("filename length mismatch");

   int ExtraLength = sourceFile.ReadWord();

   sourceFile.Close();

   System.out.println("checkLocalHeader ok");
   return pos+2+2+FileNameLength+ExtraLength;
  }
  catch (Exception e)
  {
   sourceFile.Close();
   throw new Exception(e.getMessage());
  }
 }

 //====================================================
 // .Open()
 //====================================================
 //FileName = zipfile:a:\\javaj\asimov.zip,book1\voyage.txt
 public static final TMyFile Open(String FileName) throws Exception
 {

  if (Runtime.getRuntime().totalMemory()<250000)
   {
    return TMyFile.OpenFile("resource:res/lowmemzip.txt");
   }

  int commaPos = FileName.indexOf(',');
  if (commaPos<0) throw new Exception("");
  String ZipFileName = FileName.substring(8,commaPos);
  String FileFileName = FileName.substring(commaPos+1,FileName.length()).toUpperCase();

//#DEBUG{
  System.out.println("ZipFileName="+ZipFileName);
  System.out.println("FileFileName="+FileFileName);
//#DEBUG}

  Vector list = readEntries(ZipFileName);

  //find record with specified name
  for (int i=0; i<list.size();i++)
   {
    TZipEntry entry = (TZipEntry)list.elementAt(i);
    if (entry.FileName.toUpperCase().equals(FileFileName))
     {
      System.out.println("Found record");

      int offset = CheckLocalRecord(ZipFileName, entry);

      System.out.println("file offset="+offset);

      TMyFile partialFile =  TMyPartialFile.Open(TMyMMCFile.Open(ZipFileName),offset,entry.csize);

      if (entry.method==0)
      {
       return partialFile;
      }
       else
      {
       return new TMyStreamFile(FileName, new TDecompressorStreamProvider(partialFile,entry.Length),true);
      }
     }
   }

  throw new Exception("");
 }


 //====================================================
 //public static final String[] List(String FileName)
 //====================================================
 public static final String[] List(String FileName)
 {
  Vector list = readEntries(FileName);

  String[] l = new String[list.size()];

  for (int i=0; i<list.size(); i++)
   {
    TZipEntry entry = (TZipEntry)list.elementAt(i);
    l[i]=entry.FileName;
   }

  return l;
 }


 //====================================================
 //Vector readEntries(String FileName)
 //====================================================
 //return list of entries
 private static final Vector readEntries(String ZipFileName)
 {
  Vector list = new Vector();

  if (!TMyMMCFile.Exists(ZipFileName))
   {
//    System.out.println("Zip file does not exist");
    return list;
   }

  TMyFile ZipFile = TMyMMCFile.GetOpenedFile(ZipFileName);

  boolean reusedFile = false;
  int reusedFilePos = 0;

  if (ZipFile!=null)
   {
    reusedFile=true;
    reusedFilePos=ZipFile.FilePos();
   }

  try
  {
   if (ZipFile==null)
   {
    ZipFile = TMyMMCFile.Open(ZipFileName);
   }

   int pos = ZipFile.Length - ENDHDR;

   do
   {
    if (pos < ZipFile.Length-ENDHDR-256) throw new Exception("central directory not found, probably not a zip file");
    ZipFile.Seek(pos--);
   } while (ZipFile.ReadInt() != ENDSIG);

   pos+=4+6+1;  ZipFile.Seek(pos);  //+1- account for pos--

   int count = ZipFile.ReadWord();

   pos+=2+4;  ZipFile.Seek(pos);

   pos = ZipFile.ReadInt(); //centralOffset

   ZipFile.Seek(pos);

   for (int i = 0; i < count; i++)
    {
     int sign = ZipFile.ReadInt();

     if (sign!=CENSIG) throw new Exception("Wrong Central Directory signature");

     pos+=4+2+2+2; ZipFile.Seek(pos);
     int method = ZipFile.ReadWord();

     pos+=2+2+2; ZipFile.Seek(pos);
     int crc32 = ZipFile.ReadInt();

     int csize = ZipFile.ReadInt();
     int size = ZipFile.ReadInt();
     int FileNameLength = ZipFile.ReadWord();
     int ExtraFieldLength = ZipFile.ReadWord();
     int CommentLength = ZipFile.ReadWord();

     pos+=4+4+4+2+2+2+ 2+2+4; ZipFile.Seek(pos);
     int offset = ZipFile.ReadInt();

     if (FileNameLength>255) throw new Exception("invalid FileNameLength");

     byte[] buf = new byte[FileNameLength];
     ZipFile.Read(buf,0,FileNameLength);
     pos+=4+FileNameLength+ExtraFieldLength+CommentLength;
     ZipFile.Seek(pos);

     String FileName = new String(buf,0,FileNameLength);

     if (FileNameLength>0 && FileName.charAt(FileNameLength-1)!='/')  //ignore directories
      {
       list.addElement(new TZipEntry(FileName,offset,size,csize,method));
      }
    }
  }
  catch (Exception e)
  {
   e.printStackTrace();
   list.setSize(0);
   return list;
  }
   finally
  {
   if (ZipFile!=null)
    {
     if (reusedFile)
      {
       ZipFile.Seek(reusedFilePos);
      }
       else
      {
       ZipFile.Close();
      }
    }
  }

  return list;
 }


 //===================================================
 // . SplitZipFileName()
 //===================================================
 //input = "zipfile:a:\java\file.zip,textfile.txt"
 //return = a:\java\file.zip
 public static final String SplitZipFileName(String FileName)
 {
  int commaPos = FileName.indexOf(',');
  if (commaPos<0) return "";
  return FileName.substring(8,commaPos);
 }

}

//#ZIP}
