/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


import javax.microedition.lcdui.*;

public class Displayable1 extends TextBox implements CommandListener
{
 public Displayable1()
 {
  super("ZIPExample","",500,TextField.ANY);
  try
  {
   jbInit();
  }
  catch(Exception e)
  {
   e.printStackTrace();
  }
 }

 private void jbInit() throws Exception
 {
  setCommandListener(this);
  
  addCommand(new Command("Exit", Command.EXIT, 1));
  
  //======================================
  
  String archiveName = "a:\\java\\jam\\ZIPExample\\archive.zip";
  
  //read file list from ZIP file
  String[] l = TMyZipFile.List(archiveName);

  String s = "ZIP file list: ";

  for (int i=0; i<l.length; i++)
   {
     if (i>0) s+=", \""; else s+=" \"";
     s+=l[i]+"\"";
   }

  s+="   ";

  //======================================
  //read contents of file inside ZIP
  
  TMyFile file = TMyFile.OpenFile("zipfile:"+archiveName+","+l[0]);
  
  s+="First 100 bytes from file: \""+l[0]+"\"=[";
  
  byte[] buf = new byte[100];

  file.Read(buf,0,100);
  
  s=s+new String(buf,0,100);
  
  s=s+"]";
  
  file.Close();

  setString(s);
 }

 public void commandAction(Command command, Displayable displayable)
 {
  if (command.getCommandType() == Command.EXIT)
  {
   MIDlet1.quitApp();
  }
 }

}
