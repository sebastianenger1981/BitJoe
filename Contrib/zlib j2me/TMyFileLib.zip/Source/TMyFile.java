/*
=========================================
TMyFile library for J2ME
Copyright (C) 2005 by Roman Lut
=========================================

Copyright (c) 2005 by Roman Lut. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL AUTHOR
OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 PLEASE ALSO READ LICENCES FOR:

 JZLib library port for J2ME 
  Copyright (c) 2003 Asoft ltd. All rights reserved.                            
  http://www.asoft.ru                                                                  
  Authors: Alexandre Rusev, Alexey Soloviev                                     

 JZLib library
  Copyright (c) 2000,2001,2002,2003 ymnk, JCraft,Inc. All rights reserved.
  http://www.jcraft.com/
*/


//======================================
// class TMyFile
//======================================
//common random access file interface 
//read-only by default
//to make writeable class, override Write(*) and isReadOnly()
public abstract class TMyFile
{
 public int Length;   //read only
 public String fileName;

 protected byte[] smallByteArray = new byte[4];

 //===================================================
 // Constructor
 //===================================================
 protected TMyFile(String fileName) throws Exception
 {
  this.fileName=fileName;
 }

 //=================================================
 // Factory method
 //=================================================
 public static TMyFile OpenFile(String FileName) throws Exception
 {
  if (TMyResourceFile.IsResourceFile(FileName))
   {
    return TMyResourceFile.Open(FileName);
   }
    else
  if (TMyPalmDocFile.isPalmDocFile(FileName))
   {
    return TMyPalmDocFile.Open(FileName);
   }
    else
  if (TMyTcrFile.isTcrFile(FileName))
   {
    return TMyTcrFile.Open(FileName);
   }
    else
//#ZIP{    
  if (TMyZipFile.isZipFile(FileName))
   {
    return TMyZipFile.Open(FileName);
   }
    else
//#ZIP}    
   {
    return TMyMMCFile.Open(FileName);
   }
 }

 //===============================================
 //.isNeedReindex()
 //===============================================
 public boolean isNeedReindex()
 {
  return false; 
 }
 
 //===============================================
 //.BuildIndex()
 //===============================================
 public void BuildIndex()
 {
 }
 
 //===============================================
 //.GetIndexFileName
 //===============================================
 public static final String GetIndexFileName(String FileName)
 {
//#ZIP{
   if (TMyZipFile.isZipFile(FileName))
   {
    FileName=FileName.replace(',','_');
    FileName=FileName.replace('.','_');
    FileName=FileName.replace('/','_');
    FileName=FileName.substring(8);
   }
//#ZIP}

 if (TMyResourceFile.IsResourceFile(FileName))
   {
    //"resource:res/filename.txt"
    FileName=FileName.substring(13);
   }

 int i1=FileName.lastIndexOf('.');
 if (i1>FileName.lastIndexOf('\\'))
  {
   FileName=FileName.substring(0,i1)+"_"+FileName.substring(i1+1);
  }

//#RMSMMCFILE{
//#RMSMMCFILE://  limit to 28 chars 
//#RMSMMCFILE:  int len = FileName.length();
//#RMSMMCFILE:  if (len>28)
//#RMSMMCFILE:   {
//#RMSMMCFILE:    FileName=FileName.substring(len-28);
//#RMSMMCFILE:   }
//#RMSMMCFILE} 

//#DEBUG{
  System.out.println("GetIndexFileName()="+FileName+".idx");
//#DEBUG}

  return FileName+".idx";
 }

 //===================================================
 // TMyFile.Close();
 //===================================================
 public abstract void Close();

 public abstract int FilePos();

 public abstract void Seek(int pos);
 
 public abstract void GoBack(int n);

 //===================================================
 // .getProgress();
 //===================================================
 //returns current unpacking progress 0..MAXPROGRESS
 //or -1 if file does not use unpacking, and no feedback is necessary
 public int getProgress()
 {
  return -1;
 }
 
 //===================================================
 // .AbortReadOperation();
 //===================================================
 //allows to abort current read operation
 //read operation should return with zero read bytes
 //currently ony ReadSingleByte() and ReadSingleByteReverce() supports this operation,
 //for others, behaviour is undefined
 //also abort indexing
 public void AbortReadOperation()
 {
  //default method do nothing
 }

 public abstract int Read(byte[] DestBuf, int offset, int numBytes);

 public abstract boolean ReadSingleByte(byte[] DestBuf, int offset);

 public abstract boolean ReadSingleByteReverse(byte[] DestBuf, int offset);

 //===================================================
 // TMyResourceFile.ReadInt()
 //===================================================
 public int ReadInt() throws Exception
 {
  smallByteArray[0]=0; smallByteArray[1]=0; smallByteArray[2]=0; smallByteArray[3]=0;
  Read(smallByteArray,0,4);
  return (smallByteArray[0] & 0xff) + ((smallByteArray[1] & 0xff)<<8) + ((smallByteArray[2] & 0xff)<<16) + ((smallByteArray[3] & 0xff)<<24);
 }

 //===================================================
 // TMyResourceFile.ReadWord()
 //===================================================
 public int ReadWord() throws Exception
 {
  smallByteArray[0]=0; smallByteArray[1]=0;
  Read(smallByteArray,0,2);
  return (smallByteArray[0] & 0xff) + ((smallByteArray[1] & 0xff)<<8);
 }

 //===================================================
 // .ReadBoolean()
 //===================================================
 public boolean ReadBoolean() throws Exception
 {
  return ReadByte()!=0;
 }

 //===================================================
 // TMyFile.ReadByte()
 //===================================================
 //return 0 if EOF
 public abstract byte ReadByte() throws Exception;

 //===================================================
 // .Write()
 //===================================================
 //offset - offset in buf
 public int Write(byte[] buf, int offset, int numBytes) throws Exception
 {
  throw new Exception();
 }

 //===============================================
 // .Write(int)
 //===============================================
 public void Write(int i) throws Exception
 {
  throw new Exception();
 }

 //===============================================
 // .Write(boolean)
 //===============================================
 public void Write(boolean b) throws Exception
 {
  throw new Exception();
 }

 //===============================================
 // .Write(byte)
 //===============================================
 public void Write(byte b) throws Exception
 {
  throw new Exception();
 }

 //===============================================
 // .Writeln()
 //===============================================
 public void Writeln(String s) throws Exception
 {
  throw new Exception();
 }

 //===================================================
 // .isReadOnly()
 //===================================================
 public boolean isReadOnly()
 {
  return true;
 }

 //===================================================
 // .EOF()
 //===================================================
 public boolean EOF()
 {
  return FilePos()>Length-1;
 }

 //===============================================
 // .Readln()
 //===============================================
 public String Readln() throws Exception
 {
  byte[] buf = new byte[255];
  int count=0;

  do
  {
   Read(buf,count,1);
   if (buf[count]!=10) count++;
  } while (!EOF() && count!=255 && (count==0 || buf[count-1]!=13));

  if (count>0 && buf[count-1]==13) count--;
  return Common.ByteArrayToString(buf,0,count);
 }

}


